import java.io.*;
import java.util.*;
import java.text.*;

/** 
 * resultInterpret - result of interpretation aids, FACOR and VACOR 
 */ 

public class ResultInterpret {

    public ResultInterpret ( )

    {
	// Place-holder only for the present.

    }

    /** 
     * Public methods
     */

} // End of class: ResultInterpret


