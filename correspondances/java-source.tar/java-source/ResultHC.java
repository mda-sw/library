import java.io.*;
import java.util.*;
import java.text.*;

/** 
 * resultHC - result of Hierarchical Agglomerative Clustering
 */

public class ResultHC {

    public ResultHC ( )

    {
	// Place-holder only for the present.

    }

    /** 
     * Public methods
     */

} // End of class: ResultHC


