/*---------------------------------------------------------------------------
									E.S.O.
 ----------------------------------------------------------------------------
   File name 	:	matchpnt.c
   Author 		:	Thomas Rogon
   Created on	:	08/08/99
   Language		:	ANSI C
  					Standalone module - integratable into
					the ECLIPSE library
   Description	:	This module contains all handling of the
   					matched_point_t structure.
					The matched_point_t structure is an extension
					of the eclipse dpoint structure. It contains two
					labels:
						fl (found label): the label assigned by the 
						matching algorithm (0 if no match)

						kl (known label): the label given beforehand 
						(for test purposes) (0 if unknown)
					The labels permit arbitrary permutations of the lists 
					without loss of correspondance information.

 *--------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------
   								Includes
 ---------------------------------------------------------------------------*/
#include <math.h>
#include <math.h>
#include <stdlib.h>

#include "matchpnt.h"

/* eclipse mock-ups for easy integration at a later stage */
#ifndef _ECLIPSE_TYPES_H_
#include "p2_emockup.h"
#endif
/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
#ifndef qsort_fkptr_t
typedef int(*qsort_fkptr_t)(const void*, const void*) ;
#endif



/*---------------------------------------------------------------------------
  							Function codes
 ---------------------------------------------------------------------------*/

/* get index of point with known label*/
int gkl(int lab, const matched_point_t *list, size_t lsiz)
{
   int i;
   if (!lab) /* void label */
      return -1;
   for (i=0;i<lsiz;i++){
      if (list[i].kl==lab)
	 return i;
   }
   return -1;
}



/* get index of point with found label*/
int gfl(int lab, const matched_point_t *list, size_t lsiz)
{
   int i;
   if (!lab)/* void label */
      return -1;
   for (i=0;i<lsiz;i++){
      if (list[i].fl==lab)
	 return i;
   }
   return -1;
}

/* For sorting by label (for qsort). 
Note: Unlabeled points (0) are treated as the largest,
i.e table starts with label 1, ends with label(s) 0!*/
int fl_sort(const matched_point_t*p1,const matched_point_t*p2)
{
/*	fprintf(stdout,"fls: p1=%p, p2=%p ",p1,p2);
	fprintf(stdout,"fl1=%d x1=%f y1=%f, fl2=%d x2=%f y2=%f\n",
		((matched_point_t*)p1)->fl,((dpoint*)p1)->x,((dpoint*)p1)->y,
		((matched_point_t*)p2)->fl,((dpoint*)p2)->x,((dpoint*)p2)->y); */
	if (p1->fl && p2->fl){ /* both labelled */
	   if (p1->fl > p2->fl)
	      return 1;
	   else   
	      if (p1->fl < p2->fl)
	         return -1;
          else
	      	 return 0;
    }
	if (p2->fl) 
	   return 1; /* unmatched p1 always yields to matched p2 */
	return 0;
}

/*---------------------------------------------------------------------------
 * Function	:	Find_false_matches()
 * In 		:	two matched point lists, their sizes
 * Out 		:	count of false matches
 * Job		:	The found labels are checked for correspondance
 				with the known lables
 * Notice	:	unlabeled points are ignored
 *--------------------------------------------------------------------------*/
int Find_false_matches(const matched_point_t* list1, int np1,
					   const matched_point_t* list2, int np2)
{
	int i,j;
	int fl,kl;
	int false_det=0;

	for (i=0; i<np1; i++){
		fl=list1[i].fl;
	   	if (fl){
			kl=list1[i].kl;
			for (j=0; j<np2; j++){
		   		if ((fl==list2[j].fl) &&
	   				(kl!=list2[j].kl))
/* false match */
	 				false_det++;
			}
		}
	}
	return false_det;
}

/*---------------------------------------------------------------------------
 * Function	:	print_matches()
 * In 		:	two matched point lists, their sizes,
 *				a flag (1=sort printout by found label)
 * Out 		:	0 if OK -1 if not
 * Job		:	prints out a table of 2 matched lists
 * Notice	:
 *--------------------------------------------------------------------------*/
int print_matches(matched_point_t *orglist1, int np1, 
				  matched_point_t *orglist2, int np2,
				  int sortflag, int printflags)
{
	matched_point_t *list1,*list2;
	int		err=0,i,nmax;

	nmax=max(np1,np2);	/* allocate nmax since nmatches may be the
						   largest of np1,np2 */
	list1=malloc(np1*sizeof(matched_point_t));
	list2=malloc(np2*sizeof(matched_point_t));
	memcpy(list1,orglist1,np1*sizeof(matched_point_t));
	memcpy(list2,orglist2,np2*sizeof(matched_point_t));
	if (sortflag){
		qsort(list1, np1, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort) ;
		qsort(list1, np2, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort) ;
	}
	for (i=0;i<nmax;i++){
		if (i<np1){
			printf("%8.2f %8.2f ", list1[i].c.x, list1[i].c.y);
			if (printflags & K_PRINT_LAB)
				printf("%2d %2d   ", list1[i].kl, list1[i].fl);
		}
		else{
			printf("    -         -   ");
			if (printflags & K_PRINT_LAB)
				printf("-   -   ");
		}
		if (i<np2){
			printf("%8.2f %8.2f ", list2[i].c.x, list2[i].c.y);
			if (printflags & K_PRINT_LAB)
				printf("%2d %2d\n", list2[i].kl, list2[i].fl);
			else
				printf("\n");
		}
		else{
			printf("    -         -   ");
			if (printflags & K_PRINT_LAB)
				printf("-   -   ");
			else
				printf("\n");
		}
	}
	free(list1);
	free(list2);
	return err;
}

/*---------------------------------------------------------------------------
 * Function	:	Test_false_match()
 * In 		:	A matched point from one list,
 				the second list and iis size
 * Out 		:	TRUE if the point has been falsely matched
 * Job		:	The found labels are checked for correspondance
 				with the known lables
 * Notice	:	unlabeled points are ignored
 *--------------------------------------------------------------------------*/
int Test_false_match(const matched_point_t p1, 
				     const matched_point_t* list2, int np2)
{
	int j;
	int fl,kl;

	fl=p1.fl;
	if (!fl)
		return FALSE;
	kl=p1.kl;
	for (j=0; j<np2; j++){
   		if ((fl==list2[j].fl) &&
   			(kl!=list2[j].kl))
/* false match */
 			return TRUE;
	}
	return FALSE;
}


/*---------------------------------------------------------------------------
 * Function	:	count_matches()
 * In 		:	two macthed point lists, their sizes
 				a sorting flag (1=sort lists destructively by found
				label)
 * Out 		:	match sount; -1 if not OK
 * Job		:	non null found labels are counted
 * Notice	:
 *--------------------------------------------------------------------------*/
int count_matches(matched_point_t* const list1, int np1,
				  matched_point_t* const list2, int np2, int sort)
{
	int n_matches=0,found;
	int	i,j,lastj;

	if (!list1){
		e_error("count_matches: list1 NULL\n");
		return -1;
	}
	if (!list2){
		e_error("count_matches: list2 NULL\n");
		return -1;
	}
	if (sort){
		qsort(&list1[0],np1, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort);
		qsort(&list2[0],np2, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort);
	}
    n_matches=0;
	for (i=0;i<np1;i++){
		if (list1[i].fl){
			found=0;
			for (j=0;j<np2;j++){
	    		if (list2[j].fl==list1[i].fl){
					if (found)
	       			 	e_warning(
					"labelling inconsistency i=%d j=%d lastj=%d label=%d\n",
								i,j,lastj,list1[i].fl);
					else
	        			n_matches++;
					found=1;
					lastj=j;
				}
			}
	   	}
	}
	return n_matches;
}


/*---------------------------------------------------------------------------
 * Function	:	dpoint_2_matched_point()
 * In 		:	dpoint list, number of points
 * Out 		:	matched point list, labels zeroed
 * Job		:	
 * Notice	:
 *--------------------------------------------------------------------------*/
matched_point_t *dpoint_2_matched_point(dpoint *list, int np)

{
	int 			i;
	matched_point_t *mlist;

	if (!list){
		e_error("dpoint_2_matched_point: list NULL\n");
		return NULL;
	}
	if (np<0){
		e_error("dpoint_2_matched_point: np=%d\n",np);
		return NULL;
	}
	mlist = malloc(np*sizeof(matched_point_t));
	for (i=0;i<np;i++){
		memcpy(&mlist[i].c, &list[i],sizeof(dpoint));
		mlist[i].fl=0; /* no found labels yet */
		mlist[i].kl=0; /* no a priori knowledge */
/*		printf("dpoint_2_matched_point %f %f\n",
				mlist[i].c.x,mlist[i].c.y); */
	}
	return mlist;
}

/*---------------------------------------------------------------------------
 * Function	:	attach_labels_2_matched_point()
 * In 		:	matched_point_t listis number of points,
 *				correspondance lut, which labels are affected
 *				K_FOUNDLAB	-> fl
 *				K_KNOWNLAB	-> kl
 * Out 		:	0 if OK, -1 if not
 * Job		:	
 * Notice	:
 *--------------------------------------------------------------------------*/
int attach_labels_2_matched_point(
		matched_point_t *list1, int np1, 
		matched_point_t *list2, int np2,
		int *lut, int whichlab)
{
	int i;
	int lab=0;

	if (!list1){
		e_error("attach_labels_2_matched_point: list1 NULL\n");
		return -1;
	}
	if (!list2){
		e_error("attach_labels_2_matched_point: list2 NULL\n");
		return -1;
	}
	if (np1<0){
		e_error("attach_labels_2_matched_point: np1=%d\n",np1);
		return -1;
	}
	if (np2<0){
		e_error("attach_labels_2_matched_point: np2=%d\n",np2);
		return -1;
	}
	if (whichlab==K_FOUNDLAB){
		for (i=0;i<np1;i++){
			if (lut[i]!=-1){
				list1[i].fl =++lab;
				list2[lut[i]].fl=lab;
			}
		}
	}else{	
		for (i=0;i<np1;i++){
			if (lut[i]!=-1){
				list1[i].kl =++lab;
				list2[lut[i]].kl=lab;
			}
		}
	}
	return 0;
}



/*---------------------------------------------------------------------------
 * Function	:	matched_point_2_dpoint()
 * In 		:	matched_point_t list, number of points
 * Out 		:	dpoint list labels 
 * Job		:	
 * Notice	:
 *--------------------------------------------------------------------------*/
dpoint *matched_point_2_dpoint(matched_point_t *list, int np)
{
	int i;
	dpoint *dlist;
	if (!list){
		e_error("matched_point_2_dpoint: list NULL\n");
		return NULL;
	}
	if (np<0){
		e_error("matched_point_2_dpoint: np=%d\n",np);
		return NULL;
	}
	dlist = malloc(np*sizeof(dpoint));
	for (i=0;i<np;i++){
		memcpy(&dlist[i], &list[i].c,sizeof(dpoint));
/*		printf("matched_point_2_dpoint: %f %f\n",
				dlist[i].x,dlist[i].y); */
	}
	return dlist;
}

/*---------------------------------------------------------------------------
 * Function	:	read_matched_point()
 * In 		:	Input file name, number of columnsi:
 				2= X,Y 
				3= X,Y,KNOWN_LABEL) 
 * Out 		:	matched point list
 * Job		:	
 * Notice	:	lines beginning with a hatch # are ignored
 *--------------------------------------------------------------------------*/
matched_point_t *read_matched_point(char * filename, int * np,int cols)
{
	FILE	*in ;
	matched_point_t *list ;
	int		n_points ;
	char	line[80] ;
	float	x, y ;
	int		nread ;
	int		i,l ;

	if ((in = fopen(filename, "r")) == (FILE*)NULL) {
		e_error("cannot open file %s\n", filename) ;
		return NULL ;
	}

	/* skip out comments, try to determine the number of columns */
	line[0] = '#' ;
	while (line[0] == '#') {
		fgets(line, 80, in) ;
	}
	if (sscanf(line, "%f %f", &x, &y) != 2) {
		/* sscanf did not succeed, single column input assumed */
		nread = 1 ;
	} else {
		/* sscanf succeeded, double column input assumed */
		nread = 2 ;
	}
	if (cols){  /* nonzero cols overrides autodetection (thro 050399)*/
	   nread = cols;
	}
	/* continue reading the file to determine how many points are in */
	n_points = 1 ;
	while (fgets(line, 80, in) != NULL) {
		if (line[0] != '#')
			n_points ++ ;
	}
	rewind(in) ;

	list = (matched_point_t*)malloc(n_points * sizeof(matched_point_t)) ;
	i = 0 ;
	while (fgets(line, 80, in) != NULL) {
		if (line[0] != '#') {
		   list[i].kl = 0 ;
		   list[i].fl = 0 ;
		   switch(nread){
		   case 3: 
		      if ((cols=sscanf(line, "%f %f %d", &x, &y,&l)) == 3) {
	                 list[i].c.x = (double)x ;
		         list[i].c.y = (double)y ;
		         list[i].kl = l ;
		      }
		   	else
		        printf("sscanf read %d elements\n",cols);
	            break;	
		   case 2:
		      if (sscanf(line, "%f %f", &x, &y) == 2) {
	                 list[i].c.x = (double)x ;
		         list[i].c.y = (double)y ;
		      }
		      break;
		   case 1:
		      if (sscanf(line, "%f", &y) == 1){
		         list[i].c.x = (double)i ;
			 list[i].c.y = (double)y ;
		      }
		      break;
		   default:
				e_error(
				"read_matched_point: I/O error: file=%s nread=%d n_points=%d\n",
					filename,nread,n_points );
		   }
		   i++;
		}
	}
	fclose(in) ;
	
	*np = n_points ;
	return list ;
}


/*---------------------------------------------------------------------------
 * Function	:	dump_points()
 * In 		:	output file name, matched point list nb if points
 * Out 		:	0 if OK -1 if not	
 * Job		:	dumps the matched points in a text format readable by 
 *				read_matched_point
 * Notice	:
 *--------------------------------------------------------------------------*/
int dump_points(char *fn,int np, matched_point_t *list)
{
	int		i ;
	FILE	*f ;
	int		err=0;

	f = fopen(fn, "w") ;
	if (!f)
		return -1;
	for (i=0 ; i<np ; i++) 
		fprintf(f, "%8.1f %8.1f %4d %4d\n", 
				list[i].c.x, list[i].c.y, list[i].kl, list[i].fl) ;
	fclose(f) ;
	return err;
}

