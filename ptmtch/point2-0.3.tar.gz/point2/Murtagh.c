/*---------------------------------------------------------------------------
 *
 * File name:	Murtagh.c
 * Authors	:	N. Devillard 
 * 				T. Rogon
 * Date		:	Nov 03, 1997 (initial version)
 * 				Jul 07, 1999 (rotation added, bugs in angle calculation
 * 				fixed, transformation-conditioned re-fit added) 
 * Language	:	ANSI C
 * Purpose	:	find out matches between 2 points sets
 *
 * Algorithm from:
 *	"A New Approach to Point-Pattern Matching"
 *	F. Murtagh, Publications of the Astronomical Society of the Pacific
 *	#104, April 1992, pp 301-307
 *
 * Notes:
 *
 * The algorithm makes the following assumptions on the two point sets:
 *
 * - the 2 sets are equivalent up to a linear transformation, i.e. a
 *   translation, a rotation, and a scale factor (zoom).
 * - corresponding point positions can be noisy, a displacement of up to
 *   a few pixels is tolerated.
 * - some points in a point set may have no equivalent in the other set.
 *
 * This implementation uses most choices taken by Murtagh in his paper,
 * including rotations. The output is either a list of
 * matched points, or an estimation of the offset between both point
 * lists with associated errors.
 *
 * Still to be improved:
 *
 * Silly point configurations (e.g. aligned points) could be detected by
 * a preprocessor, before trying to actually match them. The algorithm
 * obviously needs angular information to classify the points, so:
 * ---> no aligned points in input please! <---
 *
 * False detections: when feeding in two random point sets, it happens
 * that matches are found. An easy way to detect this would be to do some
 * tests on the solution stability, to see for example if the estimated
 * linear transformation does not change wildly with the addition of a
 * new point (of lesser confidence). In this change, no match would be
 * declared.
 *
 * In the same line of thought, one could also try to use as many points
 * as possible to estimate the linear transformation. It would mean
 * starting with the points which obtained the best results, and adding
 * points one by one into the solution. As long as the linear estimate
 * keeps stable, continue adding points, and stop when it goes wild. If
 * the solution goes wild from the very first points, declare it
 * unstable and return no match status.
 *
 * False rejections:
 * Apparently, it is extremely hard to obtain false rejections. If a
 * point is present in both point sets up to a linear transform, it will
 * be found -- if not too noisy. False rejections will start to be an
 * issue with the above way of declaring no match found at all.
 *
 * Do not hesitate to contact the authors in case of problems:
 * Nicolas Devillard <nDevil@eso.org>
 * Thomas  Rogon  	 <trogon@eso.org>
 *
 *-------------------------------------------------------------------------*/




/*---------------------------------------------------------------------------
 *								#includes
 *-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

/* Functionalities included from other sources */
#include "Murtagh.h"
#include "matchpnt.h"
#ifndef _ECLIPSE_TYPES_H_
#include "p2_emockup.h"
#endif


/*---------------------------------------------------------------------------
 *								#defines
 *-------------------------------------------------------------------------*/


/* For comparison sake, "world view" for all points will be resampled
 * to a single, regularly sampled interval. Murtagh suggests using a
 * simple [0..360] interval with a 1 degree sampling, the number of
 * samples can be changed here. It actually defines how many samples
 * will be used in the interval [0..360] (in degrees).  Setting this to
 * a value lower than 360 is not recommended for precision.  Above this,
 * it may be time consuming...  */
#define ANGLE_SAMPLES			(360)

/* conversion radian -> degree */
#define CONV_ANG				(180.0/M_PI)


/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
typedef int(*qsort_fkptr_t)(const void*, const void*) ;

/*---------------------------------------------------------------------------
   							Private function prototypes
 ---------------------------------------------------------------------------*/
static int         sort_dmeas_angle(const dmeas*, const dmeas*) ;
static dmeas    ** build_world_view(matched_point_t *, int) ;
static double      interpolate_distance(dmeas *, int, double) ;
static double      euclidean_distance_wv(dmeas *, dmeas *, double) ;
/* point matching function */
static match_t *match_points(matched_point_t*, int, matched_point_t*, int,
		double, double, int) ;
/* create lists of matching points for output */
static int create_matching_lists( matched_point_t *list1, int np1,
			       			   	  matched_point_t *list2, int np2,
			       match_t *matchres, match_t valid_threshold);
static int create_unique_matching_lists( matched_point_t *list1, int np1,
			       					  	 matched_point_t *list2, int np2,
			       match_t *matchres, 	match_t valid_threshold,
				   int angle_bins, 		int *best_angle_bin);


/*----------------------------------------------------------------------------
 * Function	:	match_points()
 * In 		:	two point lists
 * Out 		:	newly allocated integer array
 * Job		:	create a table containing similarity factors for all
 * 				possible point couples in both lists.
 * Notice	:
 *				- returned array allocated by malloc(), it is up to the
 *				  caller to free() it.
 *				- the array is organized in the following way:
 *				  it contains np2 lines of width np1, each element is an
 *				  integer between 0 and 1.0, 0 meaning the best possible
 *				  match, 1.0 meaning the worst.
 *				  Of course, this measurement is relative to both point
 *				  sets. The best match will always be tagged as 1.00, the
 *				  worst as 0.0. To test discrepant point sets, a test on
 *				  solution stability should be performed on this table.
 * See also :	test_solution_stability()
 *--------------------------------------------------------------------------*/
match_t *match_points(	matched_point_t *list1, int np1, 
						matched_point_t *list2, int np2,
		double angle_min, double angle_max,int angle_bins)
{
	match_t		*d_conftab ;
	int			i, j, k, kn1n2, knj ;
	int			np ;
	dmeas		**wv1, **wv2 ;
	double		conf, confmax=0.0 ;
	double		theta,dt; /* rotation, increment */
	wv1 = build_world_view(list1, np1) ;
	wv2 = build_world_view(list2, np2) ;
/* Compute matches between both world lists Store results in a double array */
	np = np1 * np2 * angle_bins; 
	d_conftab = (match_t*)calloc(np, sizeof(match_t)) ;

	theta = angle_min;
	dt = (angle_max-angle_min) / (double)angle_bins;
	for (k=0; k<angle_bins; k++){
		kn1n2 = k * np2 * np1;
		for (j=0; j<np2; j++){
			knj = j * np1 + kn1n2;
			for (i=0; i<np1; i++){
				conf = euclidean_distance_wv(wv1[i], wv2[j],theta) ;
				if (conf > confmax) 
					confmax = conf ;
				d_conftab[i+knj] = conf ;
			}
		}
		theta += dt;
	}
	for (i=0; i<np1; i++) 
		free(wv1[i]);
	for (i=0; i<np2; i++) 
		free(wv2[i]);
	free(wv1);
	free(wv2);
/* Normalize similarity to a [0..1] interval */
	for (i=0; i<np; i++) 
		d_conftab[i] = 1.0 - d_conftab[i] / confmax ;
	return d_conftab ;
}



/*----------------------------------------------------------------------------
 * Function	:	create_matching_lists()
 * In 		:	two lists of points, a matching table, a threshold for
 * 				point selection.
 * Out 		:	the 2 inputs point lists are modified. When the function
 * 				returns, they both contain the same number of points. In
 * 				each list, points have been modified so that point n in
 * 				list 1 matches point n in list 2.
 *				The number of found matches is returned.
 * Job		:	modifies 2 point lists to sort them according to point
 * 				pattern matching.
 * Notice	:	Both lists are not reallocated. The same memory space is
 * 				used, which is somewhat awkward. i.e. if 2 lists of
 * 				resp. 100 and 150 are given and 24 points have been
 * 				found to match, the first 24 points in each list will
 * 				have meaning, the rest of storage space will be still
 * 				allocated, but containing garbage.
 *--------------------------------------------------------------------------*/
static int create_matching_lists( 	matched_point_t *list1, int	np1, 
							matched_point_t *list2, int np2,
			   				match_t *matchres, match_t valid_threshold)
{
	int	i, j ;
	int	n_matches ;
	match_t best_mark ;
	int	best_pos ;

	n_matches = 0 ;
	for (i=0; i<np1; i++) {
		best_mark = WORST_MARK;
	   	best_pos  = -1 ;
	   	for (j=0; j<np2; j++) {
	    	if (matchres[i+j*np1] < best_mark) {
		 		best_mark = matchres[i+j*np1] ;
		 		best_pos  = j ;
	      	}
	   	}
	   	if (best_mark < valid_threshold) {
	    	if ((best_pos>=np2) || (best_pos==-1)){/* error situation	 */
		  		e_error(
		"Create_matching_lists: l1[%d]=%8.2f\t%8.2f -> list2[%d]\n",
		  			i,list1[i].c.x, list1[i].c.y, best_pos) ; 
		  			return 0;
	    	}
	    	n_matches ++ ;
	    	list1[i].fl=n_matches;
	    	list2[best_pos].fl=n_matches;
	  	}
	}
	return n_matches ;
}



/*----------------------------------------------------------------------------
 * Function	:	printmatchtable()
 * In 		:	a matching table of dimensions np1 * np2 * angle_bins 
 * Out 		:	void
 * Job		:	prints out the matching table 
 * Notice	:	mostly for debugging purposes
 *--------------------------------------------------------------------------*/
static void printmatchtable(match_t* matchres, int np1, int np2, 
		int angle_bins)
{
	int i,j,k;
	for (k=0;k<angle_bins;k++){
		for (j=0;j<np2;j++){
			for (i=0;i<np1;i++){
				printf("%7.5f ", matchres[i+j*np1+k*np1*np2]);
			}
			printf("\n");
		}
		printf("\n");
	}
}


/*----------------------------------------------------------------------------
 * Function	:	create_unique_matching_lists_pnt_rot()
 * In 		:	two lists of points, a matching table, a threshold for
 * 				point selection.
 * Out 		:	the 2 input point lists found label (.fl) field is modified. 
 *              The size and order of the lists is unaltered, 
 *              unmatched points found label (.fl) field is set to 0.
 *				-1 signals an error condition
 *				The number of found matches is returned.
 * Job		:   The algorithm searches a global maximum in the table
 *			matches the corresponding points and reduces the table
 * 			by the corresponding row and column. This is done 
 *			repetitively until the table is (logically) empty.
 *			(the table is not modified physically, only conceptually)
 * 			This function is similar to create_unique_matching_lists
 *			except it searches first all angle combinations for a given
 *			point instead of considering all points for a specific
 *			angle. The function is currently not used.
 *--------------------------------------------------------------------------*/
static int create_unique_matching_lists_pnt_rot( 
	matched_point_t *list1, int np1, 
	matched_point_t *list2, int np2, 
	match_t *matchres, 
	match_t valid_threshold, 
	int angle_bins, int *best_angle_bin)
{
	int		i, j, k, n1n2, nj ;
	int		n_matches ;
	int		best_col, best_row, best_angle;
	int		*col_done,*row_done;
	int		pointsleft;
	match_t	maxres, best_mark;
	int 	maxi,maxj,maxk;
	match_t	match;
	int		*angle_vote;

	if (!matchres){
		e_error("create_unique_matching_lists_pnt_rot: matchres NULL\n");
		return -1;
	}
	angle_vote= (int*)calloc(angle_bins,sizeof(int));
	col_done = (int*)malloc(np1* sizeof(int));
	row_done = (int*)malloc(np2* sizeof(int));
	*best_angle_bin=0;
/*	printmatchtable(matchres,np1,np2,angle_bins);   */
	memset(col_done,0,np1 * sizeof(int));
	memset(row_done,0,np2 * sizeof(int));
	pointsleft=min(np1,np2);
	n_matches = 0;
	n1n2 = np2 * np1;
	while (pointsleft--){
		best_mark = WORST_MARK;
	   	best_col = -1;
	   	best_row = -1;
	   	maxi = -1;
	   	maxj = -1;
		maxk = -1;
		maxres =0;
	    for (j=0; j<np2; j++) {
	       	if (row_done[j])
	           	continue;
			nj = j * np1;
	   		for (i=0; i<np1; i++) {
	    		if (col_done[i])
	       		 	continue;
				for (k=0; k<angle_bins; k++){
					match = matchres[i+nj+k*n1n2];
	               	if (maxres < match ){
				    	maxk = k;
			    		maxi = i;
			    		maxj = j;
				    	maxres = match ;
				 	}
		      	}
			}
		}
	   	best_mark = maxres ;
	   	best_row = maxj ;
	   	best_col = maxi ;
		angle_vote[maxk]++;
/* 	(seemingly impossible) error situation	*/
	   	if ((best_row==-1) || (best_col==-1) || (maxk==-1)){
	  		e_error(
"Error: create_unique_matching_lists: pointsleft=%d, maxres=%f(%d,%d,%d)\n",
		 	pointsleft,maxres,maxi,maxj,maxk); 
			return -1;
		}
	   	col_done[best_col] = TRUE;
	   	row_done[best_row] = TRUE;
	   	if (best_mark > valid_threshold) 
	   		n_matches++ ;
	}
	maxk=0;
	best_angle = 0; 
	for (k=0;k<angle_bins;k++){
		if (best_angle<angle_vote[k]){
			maxk = k;
			best_angle =angle_vote[k];
		}
		printf("angle_vote[%d]=%d\n",k,angle_vote[k]);
	}
	*best_angle_bin = maxk;
	free(col_done);
	free(row_done);
	free(angle_vote);
	printf( "best_angle_bin= %d\n", *best_angle_bin);
	return n_matches ;
}



/*----------------------------------------------------------------------------
 * Function	:	murtagh_label()
 * In 		:	two point lists & related number of points, 
 *				a rejection threshold
 *				a minimal, maximal angle & # of angle_bins for rotation
 * Out 		:	number of matches if OK, -1 if not
 *				a match table
 *				a rotation angle estimate.
 * Job		:	matches 2 point lists.
 * Notice	:	The algorithm makes the following assumptions on the 
 *				two point sets:
 * 					- the 2 sets are equivalent up to a linear 
 *						transformation, i.e. a translation, a rotation, 
 *						and a scale factor (zoom).
 * 					- corresponding point positions can be noisy, a 
 *						displacement of up to  a few pixels is tolerated.
 * 					- some points in a point set may have no equivalent 
 *						in the other set.
 * 				This implementation uses most choices taken by Murtagh in 
 * 				his paper, including rotations.
 *--------------------------------------------------------------------------*/
int murtagh_label( matched_point_t *list1, int  np1, 
				   matched_point_t *list2, int np2, int valid_threshold, 
				   double angle_min, double angle_max, int angle_bins,
				   match_t **match_tab, double *theta)
{
	int	n_matches;	/* number of found matches	*/	
	int	best_angle_bin;
	int	np;
	match_t *match_tab_rot=NULL;
	match_t scaled_val_thrshld=(100.0-(float)valid_threshold)/99.0;

	if (verbose_active())
		printf("# murtagh: angle(min,max,bins)=(%5.2f,%5.2f,%4d)\n",
				angle_min,angle_max,angle_bins);
	match_tab_rot = match_points(list1, np1, list2, np2, angle_min, angle_max,
						angle_bins) ;
	n_matches = create_unique_matching_lists(list1, np1, list2, np2, 
						match_tab_rot, scaled_val_thrshld, 
						angle_bins, &best_angle_bin) ;
	if (n_matches <0) 
		return n_matches;
	np = np1 * np2 ; 
	*match_tab = (match_t*)malloc(np* sizeof(match_t)) ;
	memcpy(*match_tab,&match_tab_rot[np*best_angle_bin],np*sizeof(match_t));
	free(match_tab_rot);
	*theta = angle_min + ((angle_max-angle_min) * best_angle_bin) / angle_bins;

/*	qsort(list1, np1, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort) ;
	qsort(list2, np2, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort) ; */
	if (verbose_active())
		printf("# theta=%5.2f matches=%4d\n",*theta,n_matches);
	return n_matches;
}


/*----------------------------------------------------------------------------
 * Function	:	murtagh()
 * In 		:	two point lists & related number of points, 
 *				a rejection threshold
 *				a minimal, maximal angle for rotation
 *				an angle precision (e.g 1.0 degs, 0.1 degs) for rotation
 * Out 		:	number of matches if OK, -1 if not
 *				a correspondance lut
 *				a rotation angle estimate.
 * Job		:	matches 2 point lists.
 * Notice	:	This is a wrapper function to murtagh_label 
 *				using eclipse data structures - see murtagh_label()
 *				for details
 *--------------------------------------------------------------------------*/
int murtagh( dpoint *srclist,  int npsrc, 
			 dpoint *destlist, int npdest,
			 int valid_threshold, double angle_min, double angle_max,
			 double angle_prec, correspond_lut **lut_src_2_dest, double *theta)
{
	matched_point_t *mlist1=NULL, *mlist2=NULL;
	match_t 		*match_tab;
	int				n_matches=-1,i,angle_bins;

	mlist1 = dpoint_2_matched_point(srclist,npsrc);
	mlist2 = dpoint_2_matched_point(destlist,npdest);
	if ( !mlist1 || !mlist2){
		e_error("murtagh: Memory full (failed allocating %d bytes)\n",
				(npsrc+npdest)*sizeof(matched_point_t));
		return -1;
	}
	if (angle_prec < MAX_ANGLE_PRECISION){
		e_error("murtagh: invalid angle precision=%f (must be >%f)\n",
				angle_prec,MAX_ANGLE_PRECISION);
		return -1;
	}
	if (angle_max<angle_min){
		e_error("murtagh: angle_min (%f) muste be < angle_max (%f)\n",
				angle_min, angle_max);
		return -1;
	}
	angle_max +=angle_prec;
	angle_bins = abs(angle_max - angle_min)/angle_prec ;
	n_matches = murtagh_label( mlist1, npsrc, mlist2, npdest,
		valid_threshold, angle_min, angle_max, angle_bins, &match_tab, theta);

	if (n_matches>0)
		*lut_src_2_dest = malloc(npsrc*sizeof(correspond_lut));
	for (i=0;i<npsrc;i++){
		if (mlist1[i].fl) /* if match exists */
			(*lut_src_2_dest)[i] = gfl(mlist1[i].fl,mlist2,npdest);
		else
			(*lut_src_2_dest)[i] = -1; /*no match */
	}
	free(mlist1);
	free(mlist2);
	free(match_tab);
	return n_matches;
}



/*----------------------------------------------------------------------------
 * Function	:	create_unique_matching_lists()
 * In 		:	two lists of points, a matching table, a threshold for
 * 				point selection.
 * Out 		:	the 2 input point lists found label (.fl) field is modified. 
 *              The size and order of the lists is unaltered, 
 *              unmatched points found label (.fl) field is set to 0.
 *				-1 signals an error condition
 *				The number of found matches is returned.
 * Job		:  	The algorithm searches a global maximum in the table
 *			matches the corresponding points and reduces the table
 * 			by the corresponding row and column. This is done 
 *			repetitively until the table is (logically) empty.
 *			(the table is not modified physically, only logically)
 *--------------------------------------------------------------------------*/
static int create_unique_matching_lists( matched_point_t *list1, int np1, 
										 matched_point_t *list2, int np2, 
								  match_t *matchres, match_t valid_threshold, 
								int angle_bins, int *best_angle_bin)
{
	typedef struct {
		match_t m;		/* the match value */
		int		a ;		/* the angle bin   */
		int		p;		/* corresponding point */
	} angle_match_t;
	int		i, j, k, kn1n2, knj ;
	int		n_matches,n_matches_max=0,n_matches_best=0;
	int		best_col, best_row;
	int		*col_done,*row_done;
	int		pointsleft;
	match_t	maxres,minres, best_mark,max_matches_mark ;
	int 	maxi,maxj,mini,minj;
	match_t	angle_mark,angle_mark_best;
	angle_match_t *preferred_angle ;	
	matched_point_t *tmp_list1, *tmp_list2;

	if (!matchres){
		e_error("create_unique_matching_lists: matchres NULL\n");
		return -1;
	}
	tmp_list1 = (matched_point_t*)malloc(np1*sizeof(matched_point_t));
	tmp_list2 = (matched_point_t*)malloc(np2*sizeof(matched_point_t));
	col_done = (int*)malloc(np1* sizeof(int));
	row_done = (int*)malloc(np2* sizeof(int));
	preferred_angle = (angle_match_t*)calloc(np1,sizeof(angle_match_t));
	*best_angle_bin=0;
	angle_mark_best=np1*np2*WORST_MARK;
/*	printmatchtable(matchres,np1,np2,angle_bins);    */
	for (k=0; k<angle_bins; k++){
		memcpy(tmp_list1,list1,np1*sizeof(matched_point_t));
		for (i=0; i<np1; i++)
			tmp_list1[i].fl =0;
		memcpy(tmp_list2,list2,np2*sizeof(matched_point_t));
		for (i=0; i<np2; i++)
			tmp_list2[i].fl =0;
		memset(col_done,0,np1 * sizeof(int));
		memset(row_done,0,np2 * sizeof(int));
		pointsleft=min(np1,np2);
		n_matches = 0;
		angle_mark =0;
		kn1n2 = k * np2 * np1;
		while (pointsleft--){
			best_mark = WORST_MARK;
		   	best_col = -1;
		   	best_row = -1;
		   	maxi = -1;
		   	maxj = -1;
		   	maxres=WORST_MARK;
		   	minres=BEST_MARK;
		    for (j=0; j<np2; j++) {
		       	if (row_done[j])
		           	continue;
				knj = j * np1 + kn1n2;
		   		for (i=0; i<np1; i++) {
		    		if (col_done[i])
		       		 	continue;
   	            	if (maxres < matchres[i+knj] ){
				    	maxi = i;
				    	maxj = j;
				    	maxres = matchres[i+knj] ;
				 	}
   		            if (minres > matchres[i+knj] ){
				    	mini = i;
				    	minj = j;
				    	minres = matchres[i+knj] ;
				 	}
		      	}
			}
		   	best_mark = maxres ;
		   	best_row = maxj ;
		   	best_col = maxi ;
/* 	(seemingly impossible) error situation	*/
		   	if ((best_row==-1) || (best_col==-1)){
		  		e_error(
"Create_unique_matching_lists: row=%d, col=%d, pointsleft=%d, minres=%f(%d,%d), maxres=%f(%d,%d)\n",
			 	best_row,best_col,pointsleft,minres,mini,minj,maxres,maxi,maxj); 
				return -1;
			}
			if (best_mark>preferred_angle[best_col].m){
				preferred_angle[best_col].m = best_mark;
				preferred_angle[best_col].a = k;
				preferred_angle[best_col].p = best_row;
			}
		   	if (best_mark > valid_threshold) {
		   		n_matches++ ;
		      	tmp_list1[best_col].fl=n_matches;
		      	tmp_list2[best_row].fl=n_matches;
		   		col_done[best_col] = TRUE;
		   		row_done[best_row] = TRUE;
				angle_mark += best_mark;
		   	}
/*			else if (k>0)
				printf("best_mark=%f, valid_threshold=%f\n",
						best_mark,valid_threshold);*/
		}
/* save max nb of matches & corresponding mark for consistency check */
		if (n_matches_max <n_matches){
			n_matches_max = n_matches;
			max_matches_mark = angle_mark;
		}
		if (debug_active())
			printf(
"angle_mark_best=%f, angle_mark=%f, k=%d, n_matches_max=%d, n_matches=%d\n",
				angle_mark_best,angle_mark,k,n_matches_max,n_matches);
		if (angle_mark_best < angle_mark){
			if (n_matches_max > n_matches){
/* Inconsistency: max nb of matches & max mark do NOT correspond */
				e_warning(
"Max matches=%d (mark=%5.2f) / best mark=%5.2f (matches=%d)\n",
						n_matches_max,max_matches_mark,angle_mark,n_matches);
			}
			angle_mark_best = angle_mark;
			*best_angle_bin =k;
			memcpy(list1,tmp_list1,np1*sizeof(matched_point_t));
			memcpy(list2,tmp_list2,np2*sizeof(matched_point_t));
			n_matches_best = n_matches;
		}
	}
	if (debug_active()){
		printf("np1=%d, np2=%d\n",np1,np2);
		for (i=0; i<np1; i++){
			if (i<np2)
			printf("i=%3d a=%3d, m=%7.4f p=%3d match=%3d/%3d known=%3d/%3d\n",
					i,
				preferred_angle[i].a, preferred_angle[i].m,
				preferred_angle[i].p, list1[i].fl,list2[i].fl,
				list1[i].kl,list2[i].kl);
			else
			printf("i=%3d a=%3d, m=%7.4f p=%3d match=%3d/ -  known=%3d/ - \n",
					i,
				preferred_angle[i].a, preferred_angle[i].m,
				preferred_angle[i].p, list1[i].fl, list1[i].kl);
		}
	}
	free(col_done);
	free(row_done);
	free(tmp_list1);
	free(tmp_list2);
	free(preferred_angle);
	if (debug_active())
		printf( "# best_angle_bin= %d\n", *best_angle_bin);
	return n_matches_best ;
}





/*----------------------------------------------------------------------------
* Function     :       rematch_lists_rmsdist()
* In           :       two lists of points:
*						  	2 input lists
*                      		the second list with applied transormation , 
*		       				a threshold for residual rematch
* Out          :       The  matched point list is modified. 
*			  				2 output lists
*                      The number of rematches is returned.
* Job          :       Rematches 2 point lists by assuming a  given 
*					   transformation  and 
*                      selecting the least squares error solution.
*--------------------------------------------------------------------------*/
int rematch_lists_rmsdist( 
	matched_point_t *ilist1, int inp1, matched_point_t *ilist2, 	int inp2,
	matched_point_t *olist1, int onp1,	matched_point_t *olist2, 	int onp2,
	matched_point_t *tlist2, 	match_t residual_threshold,
	match_t *matchres, 	int valid_threshold,	int *n_matches)
 {
 	int 	i1,i2, j, rematches=0 ;
	int 	best_pos ;
	double  resfound, /* the residual of the "Murtagh" match */
			resmin,	  /* the minimal (optimal) residual */
			res;	
	double 	x,y;		
	match_t scaled_val_thrshld=(valid_threshold-1.0)/99.0;
	
	memcpy(olist1,ilist1,inp1*sizeof(matched_point_t));
	memcpy(olist2,ilist2,inp2*sizeof(matched_point_t));
	if (debug_active())
    	printf(
		"# rematch_lists_rmsdist: residual_threshold=%f, valid_threshold=%d\n",
				residual_threshold,valid_threshold); 
	for (i1=0; i1<inp1; i1++){ /* for all points in matched table 1 */
		i2=gfl(ilist1[i1].fl, tlist2, inp2);
		if (i2>0)
	    	resfound = sqrt(SQR(ilist1[i1].c.x-tlist2[i2].c.x) +
	   		      			SQR(ilist1[i1].c.y-tlist2[i2].c.y));
		else
	    	resfound = residual_threshold;
		if (debug_active()){
  	    	printf("%8.2f %8.2f %2d %2d   ", 
				ilist1[i1].c.x, ilist1[i1].c.y, ilist1[i1].kl, ilist1[i1].fl); 
			if (i2>0)
  	    		printf("%8.2f %8.2f %2d %2d    %8.2f\n", tlist2[i2].c.x, 
					tlist2[i2].c.y, tlist2[i2].kl, tlist2[i2].fl, resfound) ; 
			else
				printf("    -        -     -  -  %8.2f\n",resfound);
		}
	   	resmin = resfound;
	   	best_pos=-1;
		if (resfound >= residual_threshold){
			x = ilist1[i1].c.x;
			y = ilist1[i1].c.y;
	      	for (j=0; j<inp2; j++){ /* rescan table 2 for better match */
	        	res = sqrt(	SQR(x-tlist2[j].c.x) + SQR(y-tlist2[j].c.y));
		 		if ((res < resmin) &&
					( (!matchres) ||
					(matchres && 
		     		(matchres[i1+j*inp1] < scaled_val_thrshld) 
					))){
	               resmin = res;
	               best_pos = j;
		 		}
	      	}
	      	if (resmin < resfound){
	        	if (best_pos == -1)
		    		e_error("rematch_lists_rmsdist: best_pos=%d, i1=%d, i2=%d\n",
							best_pos,i1,i2);
				else{
			 		if (ilist1[i1].fl) /* if this point has been labelled... */
			    		olist2[best_pos].fl=ilist1[i1].fl;
			 		else
			    		olist2[best_pos].fl=olist1[i1].fl=++*n_matches;
					if (i2>0)
						olist2[i2].fl=0;
					if (debug_active())
			 			printf(
"# rematched (%3d): %8.2f,%8.2f,%d,%d into %8.2f,%8.2f,%d,%d (%8.2f) was %8.2f,%8.2f,%d,%d (%8.2f)\n",
						i1, x,y,olist1[i1].kl,olist1[i1].fl,
						olist2[best_pos].c.x,olist2[best_pos].c.y,
						olist2[best_pos].kl,olist2[best_pos].fl,resmin,
						ilist2[best_pos].c.x,ilist2[best_pos].c.y,
						ilist2[best_pos].kl,ilist2[best_pos].fl,resfound);
		        	 rematches++; 
				}
	      	}
	   	}
	}
	return rematches;
}


/*----------------------------------------------------------------------------
* Function     :	remove_list_redundancies()
* In           :    2 matched lists
*                   2 transformed lists tlist2,otlist2 
* Out          :    The 2nd matched point list is modified. 
*                   The number of rematches is returned.
* Job          :    Rematches 2 point lists by removing redundancies i.e.
*		       		mulitple points in list1 matched to single point in list2
*                   The match is performed under the constraint of least sum 
*		       		of square error.
* Notice	:      	The rematch may create new redundancies; Repeated calls
*	               	of this procedure should reduce the redundancies, but 
*		       		there is no guarantee of convergence (!)
*--------------------------------------------------------------------------*/
#define MAX_RED 10 /* max supported redundant matches of any point  */
int remove_list_redundancies( 
	matched_point_t *rlist1, int rp1, matched_point_t *rlist2, int rp2,
    matched_point_t *olist1, int op1, matched_point_t *olist2, int op2,
    matched_point_t *trlist2, matched_point_t *otlist2,  match_t  *matchres,
	int valid_threshold, int resmax)
 {
 	int 	i,j,k,red_count;
	int 	best_pos=0,ti ;
	int		red[MAX_RED+1],rematches[MAX_RED+1]; /*0th being the original,
											   tables must majored by 1 */
	double  resid[MAX_RED+1],resmin,res; /* residuals of the redundants */
	double  sx,sy,tr; 
	match_t scaled_val_thrshld=(valid_threshold-1.0)/99.0;
/*	trlist2  = malloc(rp2*sizeof(matched_point_t));
	otlist2 = malloc(op2*sizeof(matched_point_t));
	(*xform->xform_fkptr)(rlist2,rp2,xform->pb,tlist2,&rp2);
	(*xform->xform_fkptr)(olist2,op2,xform->pb,otlist2,&op2); */

	for (i=0;i<MAX_RED+1;i++){ /* clear stats */
	   rematches[i]=0;
	   red[i]=0;
	   resid[i]=0.0;
	}
	for (i=0; i<rp2-1; i++){/*for all points in (redundance plagued) table 2*/
		sx = rlist2[i].c.x;
	   	sy = rlist2[i].c.y;
	   	red_count =0;
	   	red[red_count] = i;
	   	for (j=i+1; j<rp2; j++){ /* search for redundancy */
	    	if ((sx==rlist2[j].c.x) && (sy==rlist2[j].c.y)){  
		 		if (red_count<MAX_RED)
	      	    	red[++red_count] = j;
		 		else
		    		e_warning("Maximum match redundancy (%d) exceeded!\n",MAX_RED);
    	   	}
	   	}
	   	if (red_count){ /* redundant matches found */
	   		rematches[red_count]++;
	      	resid[0] = sqrt(
				SQR(rlist1[i].c.x - trlist2[i].c.x) +
			    SQR(rlist1[i].c.y - trlist2[i].c.y));
	      	for (j=1; j<=red_count;j++){
		 		resid[j] = sqrt(
					SQR(rlist1[red[j]].c.x - trlist2[red[j]].c.x) +
				 	SQR(rlist1[red[j]].c.y - trlist2[red[j]].c.y));
			}	
/* sort by increasing residual	
	      printf("# %d redundancies: %8.2f,%8.2f
into:",red_count,rlist2[i].c.x,rlist2[i].c.y); */
		    for (j=0;j<=red_count;j++){
		      	for (k=j+1;k<=red_count;k++){
					if (resid[k] < resid[j]) {
						tr = resid[j];
						resid[j]=resid[k];
						resid[k]=tr;
						ti = red[j];
						red[j]=red[k];
						red[k]=ti;
			    	}
			 	}
/*	         printf("\n#\t\t%d %8.2f,%8.2f
 *	         (%8.2f)",red[j],rlist1[red[j]].c.x,rlist1[red[j]].c.y,resid[j]);
 *	         */
			}
/* rematch redundants from matched table 1 into original table 2 */
		    for (j=1;j<=red_count;j++){ /* skip 1st (optimal) occurrence...  */
		    	best_pos = -1;
			 	resmin=resmax;
		        for (k=0;k<op2;k++){ /* for all points in original list2 */
		            res = sqrt(SQR(rlist1[red[j]].c.x-otlist2[k].c.x) +
		                       SQR(rlist1[red[j]].c.y-otlist2[k].c.y));
		            if (res < resmax){ 
/* same point*/
		            	if ((sx==olist2[k].c.x) && (sy==olist2[k].c.y)) 
			          		continue; /* skip it! */
			       		if (matchres[ red[j] + k*op1] < scaled_val_thrshld){ 
/* candidate acceptable to Murtagh */
		                  	resmin = res;
		                  	best_pos = k;
			       		}
/*			       else
		          fprintf(stderr,"Red reject %d
				  (%8.2f,%8.2f)\n",k,olist2[k].c.x,olist2[k].c.y); */
		            }
			 	}
			 	if (best_pos==-1){ /* no better match found */
/*un-match this point */
			    	rlist2[red[j]].fl = rlist1[red[j]].fl = 0;
/* printf("\n# unmatched : %8.2f %8.2f %2d %2d   %8.2f %8.2f %2d %2d ",
 rlist1[red[j]].c.x,rlist1[red[j]].c.y,rlist1[red[j]].kl,rlist1[red[j]].fl,
 rlist2[red[j]].c.x,rlist2[red[j]].c.y,rlist2[red[j]].kl,rlist1[red[j]].fl); */
			 	}
			 	else{
/*printf("\n# rematched : %8.2f,%8.2f into %8.2f,%8.2f (%8.2f)",
rlist1[red[j]].c.x,rlist1[red[j]].c.y,olist2[best_pos].c.x,olist2[best_pos].c.y,resmin); */
		            memcpy(&rlist2[red[j]], &olist2[best_pos],sizeof(matched_point_t));
/* make sure label is up to date */
		            rlist2[red[j]].fl = rlist1[red[j]].fl;
			 	}
			}
/*	      if (best_pos!=-1)
	         printf("\n"); */
	   	}
	}
/*	printf("\n# redundancy statistics:"); */
	for (i=1;i<MAX_RED;i++){ /* sum stats */
	   rematches[0]+=rematches[i];
/*	   printf("\n# %d: (%d)",i,rematches[i]); */
	}
/*	free(tlist2);
	free(otlist2); */
	return rematches[0];
}



/*----------------------------------------------------------------------------
 * Function	:	build_world_view()
 * In 		:	list of points, number of points in this list
 * Out 		:	a world view
 * Job		:	build the world view associated to a point list
 * Notice	:	definition of a world view: see Murtagh's article
 *--------------------------------------------------------------------------*/
static dmeas **build_world_view( matched_point_t *list, int np)
{
	int			i, j ;
	double		max_dist=0.0, min_dist=1e10 ;
	double		norm ;
	double		dis, ang, ang_step ;
	double		diff_x, diff_y ;
	dmeas		*wv, **list_wv, **list_mes ; 
/* 	First pass: compute distance and angle for all point pairs in
	 this data set, and get minimum and maximum distance.  */
	list_wv = (dmeas**)calloc(np, sizeof(dmeas*)) ;
	for (i=0 ; i<np ; i++) {
		wv = (dmeas*)calloc(np, sizeof(dmeas)) ;
		for (j=0 ; j<np ; j++) {
			dis = SQR(list[i].c.x-list[j].c.x) + SQR(list[i].c.y-list[j].c.y) ;
			dis = sqrt(dis) ;
			diff_x = list[j].c.x - list[i].c.x ;
			diff_y = list[j].c.y - list[i].c.y ;
			if (fabs(dis)>1e-10) {
				if (diff_x >= 0.0) {
/* 2 right quadrants */
					ang = asin(diff_y/dis) ;
				} else {
/* 2 left quadrants */
					ang = M_PI-asin(diff_y/dis) ;
				}
			} else 
				ang = 0.00 ;
			ang *= CONV_ANG ;
			if (ang<0.0) 
				ang += 360.0 ;
			else
				if (ang>360.0) 
					ang -= 360.0 ;
			if (dis>max_dist) 
				max_dist = dis ;
			else 
				if (dis<min_dist) 
					min_dist = dis ;
			if (dis <0.0)
				e_warning("build_world_view: i=%d, j=%d, dis=%f\n",
						i,j,dis);
			if ((ang<0.0) || (ang>360.0))
				e_warning("build_world_view: i=%d, j=%d, ang=%f\n",
						i,j,ang);
			wv[j].dis = dis ;
			wv[j].ang = ang ;
		}
		list_wv[i] = wv ;
	}
/* Second pass: normalize distances to [0..1] Attention:
	0.00 is the greatest distance in the set
 	1.00 is the smallest distance (from a point to itself) */
	norm = 1.00 / (max_dist - min_dist) ;
/*	fprintf(stderr, "build_world_view: max_dist=%f\n",max_dist); */
	for (i=0 ; i<np ; i++) 
		for (j=0 ; j<np ; j++){
/*			list_wv[i][j].dis =
				norm * (max_dist - list_wv[i][j].dis) ; */
			if (i!=j)
				list_wv[i][j].dis =
					(1.1 * max_dist - list_wv[i][j].dis)/(1.1*max_dist);
			else 
				list_wv[i][j].dis = 0.0;
/*			fprintf(stderr,
				"build_world_view: list_wv[%d][%d].dis=%f ang=%7.2f\n",
						i,j,list_wv[i][j].dis,list_wv[i][j].ang); */
		}
/* Now sort out each array by increasing angle */
	for (i=0; i<np; i++){
		qsort(list_wv[i], np, sizeof(dmeas), (qsort_fkptr_t)sort_dmeas_angle) ;
/*		for (j=0; j<np; j++) {
			fprintf(stderr,
				"qsort: list_wv[%d][%d].dis=%f ang=%7.2f\n",
						i,j,list_wv[i][j].dis,list_wv[i][j].ang);
		} */
	}
/* Resample each signal from (theta, distance) to (itheta, distance) */
	list_mes = (dmeas**)calloc(np, sizeof(dmeas*)) ;
	ang_step = 360.0 / (double)ANGLE_SAMPLES ;
	for (i=0; i<np; i++) {
		list_mes[i] = (dmeas*)calloc(ANGLE_SAMPLES, sizeof(dmeas)) ;
		for (j=0; j<ANGLE_SAMPLES ; j++) {
			list_mes[i][j].ang = (double)j * ang_step ;
			list_mes[i][j].dis = interpolate_distance(list_wv[i],
										np, list_mes[i][j].ang) ;
/*				fprintf(stderr,
					"build_world_view: list_mes[%d][%d].dis=%f,ang=%7.2f\n",
						i,j,list_mes[i][j].dis,list_mes[i][j].ang);*/
		}
	}
/* Now we have a resampled measurement, free the initial array */
	for (i=0 ; i<np ; i++) 
		free(list_wv[i]) ;
	free(list_wv) ;
	return list_mes ;
}




/*----------------------------------------------------------------------------
 * Function	:	sort_dmeas_angle()
 * In 		:	2 pointers to dmeas
 * Out 		:	1 or -1	
 * Job		:	compares two angles in dmeas structures
 * Notice	:	to be used with qsort (from libc)
 *--------------------------------------------------------------------------*/
static int sort_dmeas_angle(const dmeas* v1, const dmeas* v2)
{
/* angles are expected in [0..360] */
	if (v1->ang <0.0)
		e_warning("sort_dmeas_angle: v1.ang=%f\n",v1->ang);
	else
		if (v1->ang >360.0)
			e_warning("sort_dmeas_angle: v1.ang=%f\n",v1->ang);
	if (v2->ang <0.0)
		e_warning("sort_dmeas_angle: v2.ang=%f\n",v2->ang);
	else
		if (v2->ang >360.0)
			e_warning("sort_dmeas_angle: v2.ang=%f\n",v2->ang);
	if (v1->ang > v2->ang)
		return 1 ;
	else
		if (v1->ang < v2->ang)
			return -1 ;
		else
			return 0;
}


/*----------------------------------------------------------------------------
 * Function	:	interpolate_distance()
 * In 		:	an array of dmeas, number of points in this array, an
 * 				angle.
 * Out 		:	an interpolated distance for the given angle
 * Job		:	interpolates a distance in a dmeas array from an angle
 * Notice	:	see article for more information.
 *--------------------------------------------------------------------------*/
static double interpolate_distance( dmeas *m, int np, double iang)
{
	double	interp ;
	double	a1, a2,angdiff,angmod ;
	double	d1, d2 ;
	int		i1, i2 ;
	double	s_a, s_b ;

/*  Find out the first angle in the array which is greater than the
 * requested angle value */
	i1 = 1 ;
	angmod = 0.0;
	while ((i1<np) && (m[i1].ang < iang)) 
		i1++ ;
	if ((i1==1) && (m[i1].ang > iang) ) { /* wrap around */
		i1 = np-1;
		if (m[i1].ang > iang) /* wrap around */
			angmod = 360.0 ;
	}
	else
		if (i1!=1)
			i1--;
	a1 = m[i1].ang - angmod;

	angmod = 0.0;
	i2 = i1+1 ;
	if (i2==np){/* wrap around */
		i2 = 1;
		if (m[i2].ang < iang) /* wrap around */
			angmod = 360.0 ;
	}
	a2 = m[i2].ang + angmod;

	d1 = m[i1].dis ;
	d2 = m[i2].dis ;
	if (d1 <0.0)
		e_warning("interpolate_distance: d1=%f, i1=%d\n",d1,i1);
	if (d2 <0.0)
		e_warning("interpolate_distance: d2=%f, i2=%d\n",d2,i2);
/* Linear interpolation between these values */
	angdiff = a2-a1;
	if (fabs(angdiff)<1e-4){
/*		if (debug_active())
			e_warning(
"h/v aligned points: v=%5.2f d1=%5.2f d2=%5.2f a1=%5.2f a2=%5.2f iang=%4.0f i1=%4d i2=%d\n",
		(d1+d2)*0.5,d1,d2,a1,a2,iang,i1,i2); */
		return (d1+d2)*0.5 ; 
	}

	if (angdiff<0.0)
		e_warning("a1=%6.2f, a2=%6.2f, angdiff=%6.2f\n",
				a1,a2,angdiff);
	s_a = (d2-d1)/(a2-a1) ;
	s_b = d1 - s_a * a1 ; 

	interp = s_a * (double)iang + s_b ;
/*	fprintf(stderr,
"val=%5.2f d1=%5.2f d2=%5.2f a1=%5.2f a2=%5.2f iang=%4.0f i1=%4d i2=%d\n",
		interp,	d1,d2,a1,a2,iang,i1,i2); */
	return interp ;	
}


/*----------------------------------------------------------------------------
 * Function	:	euclidean_distance_wv()
 * In 		:	two pointers to dmeas structures
 * Out 		:	a double
 * Job		:	compute the euclidean distance between 2 dmeas arrays,
 *				dist = sqrt( sum{ wv1[i].dis - wv2[i].dis }^2) 
 * Notice	:	real euclidean distance: if A=B, dist(A,B)=0
 *				see article for more information
 *--------------------------------------------------------------------------*/
static double euclidean_distance_wv( dmeas *wv1, dmeas *wv2, 
		double theta)
{
	int		i,rot_i ;
	double	distance=0.0/*,val*/ ;

	for (i=0; i<ANGLE_SAMPLES; i++) {
		rot_i = i + (theta/360.0)*(double)ANGLE_SAMPLES; 
		if (rot_i >=ANGLE_SAMPLES)
			rot_i -= ANGLE_SAMPLES;
		else
			if (rot_i<0)
				rot_i += ANGLE_SAMPLES;
		distance += SQR(wv1[i].dis - wv2[rot_i].dis) ;
/*		val = SQR(wv1[i].dis - wv2[rot_i].dis) ;
		if ( (theta<1.0) || (theta>179.0)){
			printf("%8.0f %8d %8.3f %8d %8.3f %8.3f\n",
					theta,i,wv1[i].dis,rot_i,wv2[rot_i].dis,val); 
		} */
	}
	distance = sqrt(distance) ; 
	return distance ;
}
/*--------------------------------------------------------------------------*/
