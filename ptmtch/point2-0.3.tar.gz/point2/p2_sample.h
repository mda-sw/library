/*---------------------------------------------------------------------------
									E.S.O.
 ----------------------------------------------------------------------------
   File name 	:	sample.h
   Author 		:	Thomas Rogon
   Created on	:	08.08.99
   Language		:	ANSI C
   					Standalone module / 
  					Integratable into ECLIPSE library
   Description	:
 *--------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------
 *								#defines
 *-------------------------------------------------------------------------*/
#define ANGMIN_DEF 0.0
/*#define ANGMAX_DEF 359.0 */
#define ANGMAX_DEF  0.0
#define ANGPREC_DEF 1.0

#define NUMP_DEF	10
#define THRSHLD_DEF	30
#define SIGMA_DEF	10.0

/* output flag values */
#define NO_OUTPUT			0
#define OUTPUT_PAIRS		1
#define OUTPUT_OFFSETS 		2 
#define REMATCH				4 
#define REMOVE_REDUNDANTS	5 


#define LINEAR_XFORM		0
#define POLY2D_XFORM		1

/* Matching threshold: a confidence is given as a number in [1..100]
 * 1 being the best match
 * 100 being the worst
 * This is the default threshold below which a match is considered as valid
 * Ideally, it should be user-selectable.  */
#define BEST_MATCHES			(30)

/*---------------------------------------------------------------------------
 * Function	:	sample()
 * In 		:	2 point lists to match with respective point numbers
 *				a rejection threshold
 * Out 		:	0 if OK -1 if not
 				median and mean errors on linear transformations
				nb of false matches (if input point lists include 
				valid known labels
				search angles (min,max,precision)
				a flag signalling if known labels are present (==1)
 * Job		:	performs Murtagh point pattern matching,
 *				(optionally) applies a transformation,
 				performs a rematch assuming the transformation
 * Notice	:	only linear transformation currently implemented
 *--------------------------------------------------------------------------*/
int sample(char output_flag, 
	matched_point_t *list1, int  np1,
	matched_point_t *list2, int np2,
	int    valid_threshold, 
	double *errMed, double *errMean,int *fm,
	float angmin, float angmax, double angle_prec,
	int known_labels);

