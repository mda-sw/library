/*---------------------------------------------------------------------------
 *
 * File name:	xform.c
 * Author	:	T. Rogon / N. Devillard 
 * Date		:	08.08.99
 * Language	:	ANSI C
 * Purpose	:	simple transformations (translation & rotoation)
 *				between 2 points sets
 *
 * The algorithm makes the following assumptions on the two point sets:
 *
 * - the 2 sets are equivalent up to a linear transformation, i.e. a
 *   translation, a rotation.
 *
 * Do not hesitate to contact the authoris in case of problems:
 * Thomas Rogon <trogon@eso.org>
 * Nicolas Devillard <nDevil@eso.org>
 *
 *-------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
 *								#includes
 *-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "matchpnt.h"
#include "p2_lin_xform.h"
/* eclipse mock-ups for easy integration at a later stage */
#ifndef _ECLIPSE_TYPES_H_
#include "p2_emockup.h"
#endif


/*---------------------------------------------------------------------------
 *								#defines
 *-------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
typedef int(*qsort_fkptr_t)(const void*, const void*) ;

/* hack to pass Mean & median values */
double gdeltaMed[4];
double gdeltaMean[4];

/*---------------------------------------------------------------------------
   							Private function prototypes
 ---------------------------------------------------------------------------*/
static int double_sort(const void * d1, const void * d2) ;

/* Comparison function for qsort */
int double_sort(const void * d1, const void * d2)
{ 
	if (*(double*)d1 > *(double*)d2) 
		return 1 ; 
	else 
		return -1 ; 
}


/*----------------------------------------------------------------------------
 * Function	:	get_mean_offsets()
 * In 		:	two point lists, number of points in both lists
 * Out 		:	a pointer to a zone containing 4 doubles
 * Job		:	compute a mean offset in (dx,dy) and the average
 * 				square error associated to this offset.
 * Notice	:
 *--------------------------------------------------------------------------*/
double *get_mean_offsets( matched_point_t *list1, matched_point_t	*list2, int	n_matches)
{
	double	*delta,mx,my ;
	int	i ;
	double	dx=0.0, dy=0.0 ;
	double	sq_sum_x=0.0, sq_sum_y=0.0 ;

/* delta[0] stores dx
 delta[1] stores the average square error on dx
 delta[2] stores dy
 delta[3] stores the average square error on dy */
	delta = (double*)calloc(4, sizeof(double)) ;

	for (i=0 ; i<n_matches ; i++) {
		mx =  list1[i].c.x - list2[i].c.x ; 
		my =  list1[i].c.y - list2[i].c.y ; 
		dx +=  mx ; 
		dy +=  my ; 
		sq_sum_x += SQR(mx) ;
		sq_sum_y += SQR(my) ;
	}
	delta[0] = dx/(double) n_matches;
	delta[2] = dy /(double) n_matches;

	delta[1] = sq_sum_x / (double)n_matches - SQR(delta[0]);
	delta[3] = sq_sum_y / (double)n_matches - SQR(delta[2]);

	return delta ;
}


/*----------------------------------------------------------------------------
 * Function	:	get_median_offsets()
 * In 		:	two point lists, number of points in both lists
 * Out 		:	a pointer to a zone containing 4 doubles
 * Job		:	compute a median offset in (dx,dy) and the average
 * 				square error associated to this offset.
 * Notice	:
 *--------------------------------------------------------------------------*/
double *get_median_offsets( matched_point_t *list1, matched_point_t *list2, int n_matches)
{
	double	*delta ;
	int		i ;
	double	*dx, *dy ;
	double	sq_sum_x, sq_sum_y ;

/* 	delta[0] stores dx
	delta[1] stores the average square error on dx
	delta[2] stores dy
	delta[3] stores the average square error on dy */
	delta = (double*)calloc(4, sizeof(double)) ;
	dx    = (double*)calloc(n_matches, sizeof(double)) ;
	dy    = (double*)calloc(n_matches, sizeof(double)) ;

	for (i=0 ; i<n_matches ; i++) {
		dx[i] = list1[i].c.x - list2[i].c.x ; 
		dy[i] = list1[i].c.y - list2[i].c.y ; 
	}
	qsort(dx, n_matches, sizeof(double), (qsort_fkptr_t)double_sort) ;
	qsort(dy, n_matches, sizeof(double), (qsort_fkptr_t)double_sort) ;
	if (n_matches%2) {
/* odd number of elements in the array */
		delta[0] = dx[n_matches/2] ;
		delta[2] = dy[n_matches/2] ;
	} else {
/* even number of elements in the array */
		delta[0] = 0.5 * (dx[(n_matches/2)-1] + dx[n_matches/2]) ;
		delta[2] = 0.5 * (dy[(n_matches/2)-1] + dy[n_matches/2]) ;
	}

/* Now compute the errors for this median displacement */
	sq_sum_x = 0.00 ;
	sq_sum_y = 0.00 ;
	for (i=0 ; i<n_matches ; i++) {
		sq_sum_x += SQR(dx[i] - delta[0]) ;
		sq_sum_y += SQR(dy[i] - delta[2]) ;
	}
	delta[1] = sq_sum_x / (double)n_matches ;
	delta[3] = sq_sum_y / (double)n_matches ;

	free(dx) ;
	free(dy) ;
	return delta ;
}


/*----------------------------------------------------------------------------
 * Function	:	rotate()
 * In 		:	a point lists, number of points in list,
 *				rotation angle in degrees
 * Out 		:	0 if OK, -1 if not
 * Job		:	rotate point list around origin (0,0)
 * Notice	:
 *--------------------------------------------------------------------------*/
int rotate(double angle, matched_point_t *inlist, int np)
{
	int i;
	int err=0;
	double c,s,theta,x,y;
	
	if (!inlist){
		e_error("rotate: inlist NULL");
		return -1;
	}
	if (np<=0)
		e_warning("rotate: nothing to do np=%d",np);
	else
		if (verbose_active()) 
			printf("# rotating %f degrees\n",angle);
	theta = (angle * 2.0 * M_PI)/ 360.0;
	c = cos(theta);
	s = sin(theta);

	for (i=0; i<np; i++){
		x = inlist[i].c.x;
		y = inlist[i].c.y;
		inlist[i].c.x = x * c - y * s;
		inlist[i].c.y = x * s + y * c;
	}
	return err;
}


/*
int test_chi(matched_point_t *rlist1, matched_point_t *rlist2, 
		simple_xform_t *xform, int n_matches)
{
	int		i;
	double  *obs,prob,chi_val;

	obs = (double*)malloc(n_matches*sizeof(double));

	for (i=0;i<n_matches;i++) 
		obs[i]=rlist1[i].c.x-rlist2[i].c.x;
	prob=Chi_test(obs,n_matches,xform->dx,1,&chi_val);
	printf("X=%7.2f: P(Chi2(%3d)<=%8.2f)=%8.4f\n",
			xform->dx,n_matches-1,chi_val,prob);
	for (i=0;i<n_matches;i++) 
		obs[i]=rlist1[i].c.y-rlist2[i].c.y;
	prob=Chi_test(obs,n_matches,xform->dy,1,&chi_val);
	printf("Y=%7.2f: P(Chi2(%3d)<=%8.2f)=%8.4f\n",
			xform->dy,n_matches-1,chi_val,prob);
	free(obs);
	return 0;
}
*/

int check_true_xform(const matched_point_t *slist1, int np1,
					 const matched_point_t *slist2, int np2,
					 double *true_dx, double *true_dy)
{
	int		k=0,i,j;
	int 	err=0;
	double 	edx=0.0,edy=0.0;

	for (i=0;i<np1;i++){ /* must be np1 since list1 may have been permuted */
		j= gkl(slist1[i].kl,slist2,np2); 
	   	if (j>=0){ /* match found */
	    	edx += slist1[i].c.x - slist2[j].c.x;	
	   		edy += slist1[i].c.y - slist2[j].c.y;	
	      	k++;
	   	}	
/*	   	else
			if (debug_active()){
				printf("* %8.2f %8.2f %4d %4d ",slist1[i].c.x,slist1[i].c.y,
						slist1[i].fl,slist1[i].kl);	
				if (i<np2)
			    	printf("%8.2f %8.2f %4d %4d\n",slist2[i].c.x,slist2[i].c.y,
						slist2[i].fl,slist2[i].kl);	
				printf("i=%d - j=%d\n",i,j);
			}*/
	}
	if (k){
	   *true_dx = edx / k;
	   *true_dy= edy / k;
	   if (debug_active())
		   printf("# true_xform: dx=%8.2f dy=%8.2f (%d matches %d/%d points)\n",
			*true_dx,*true_dy,k,np1,np2);	   
	}
	else{
	   *true_dx = 0.0;
	   *true_dy = 0.0;
	   err = -1;
	}
	return err;
}



int apply_simple_xform(	matched_point_t *ilist, int inp, 
						char *pb,
			   		 	matched_point_t *olist, int *onp)
{
	int 			i,err=0;
	simple_xform_t *sform;

	sform = (simple_xform_t *)pb;
/* apply transaltion */	
	if (verbose_active()) 
		printf("# translating %d points by %f %f\n",inp,sform->dx,sform->dy);
	for (i=0;i<inp;i++){
		memcpy(&olist[i],&ilist[i],sizeof(matched_point_t));
		olist[i].c.x = ilist[i].c.x + sform->dx;
		olist[i].c.y = ilist[i].c.y + sform->dy;
	}
	*onp=inp;
	err=rotate(sform->rot,olist,*onp);
	return err;
}


int Find_simple_xform(matched_point_t *slist1, int np1, 
			   		  matched_point_t *slist2, int np2,
			   		  int n_matches, xform_t *xform,
			   		  char printout)
{
	int 	err=0,i;
	simple_xform_t *sform;
	double *deltaMed=NULL,*deltaMean=NULL;

	if (debug_active())
		printf("# Finding simple x-form (rotation/translation)\n");
	if (xform->p_size != sizeof(simple_xform_t)){
		fprintf(stderr,"wrong size of simple x-form %d (%d expected)\n",
				xform->p_size, sizeof(simple_xform_t));
		return -1;
	}
	sform = (simple_xform_t*)xform->pb;

	err=rotate(sform->rot,slist2,np2);
	if (err)
		return err;
/*	print_matches(slist1, n_matches,
				  slist2, n_matches, n_matches, 0);*/
	deltaMed = get_median_offsets(slist1, slist2, n_matches) ;
	deltaMean = get_mean_offsets( slist1, slist2, n_matches) ;
	if (printout) {
		printf("# median dx= %8.2f [%8.2f]\tdy=%8.2f [%8.2f]\n", 
				deltaMed[0], deltaMed[1], deltaMed[2],
				deltaMed[3]) ;
		printf("# mean   dx= %8.2f [%8.2f]\tdy=%8.2f [%8.2f]\n",
				deltaMean[0], deltaMean[1], deltaMean[2],
			  	deltaMean[3]) ;
	}
	if (deltaMed[1] < deltaMean[1] &&
		deltaMed[3] < deltaMean[3] ){
		if (printout) 
			printf("# selecting median\n"); 
		sform->dx = deltaMed[0];
		sform->dy = deltaMed[2];
	}else{
		if (printout) 
			printf("# selecting mean\n"); 
		sform->dx = deltaMean[0];
		sform->dy = deltaMean[2];
	}
	for (i=0;i<4;i++){
		gdeltaMed[i]  = deltaMed[i];
		gdeltaMean[i] = deltaMean[i];
	}

	xform->xform_fkptr = (xform_fkptr_t) apply_simple_xform;
	free(deltaMed);
	free(deltaMean);

	return err;
}


int Find_xform(const matched_point_t *list1, int np1, 
			   const matched_point_t *list2, int np2,
			   int   n_matches, xform_t *xform,
				xformeval_fkptr_t xformeval_fkptr,
				char printfl,
			   double **deltaMean, double **deltaMed,
			   double *errMed, double *errMean)
{
	matched_point_t *slist1,*slist2; /* sorted lists */
	double	true_dx,true_dy;
	int 	err=0,i;
	
	slist1=malloc(np1*sizeof(matched_point_t));
	slist2=malloc(np2*sizeof(matched_point_t));
	memcpy(slist1,list1,np1*sizeof(matched_point_t));
	memcpy(slist2,list2,np2*sizeof(matched_point_t));
/* sort lists with respect to the found label for mean/median
 * translation evaluation */
/*	print_matches(slist1, np1, slist2, np2, n_matches, 0); */
	if (debug_active())
		printf("# sorting lists w/r to found labels (%d/%d points)\n",
				np1,np2);

	qsort(slist1, np1, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort) ;
	qsort(slist2, np2, sizeof(matched_point_t), (qsort_fkptr_t)fl_sort) ; 
	(*xformeval_fkptr)(slist1,np1,slist2,np2,n_matches,xform,printfl);
	*deltaMed = malloc(4*sizeof(double));
	*deltaMean = malloc(4*sizeof(double));
	for (i=0;i<4;i++){
		(*deltaMed)[i]  = gdeltaMed[i];
		(*deltaMean)[i] = gdeltaMean[i];
	}
	err=check_true_xform(slist1,np1,slist2,np2,&true_dx,&true_dy);
	if (err){
		if (verbose_active())
			fprintf(stderr,"# Unknown a priori labels\n");
		err=0;
		*errMean = 0.0;
		*errMed = 0.0;
	}
	else{
		printf("# effective dx=%8.2f dy=%8.2f\n",true_dx,true_dy);
	   	*errMean = sqrt(SQR((*deltaMean)[0] - true_dx) + 
			   		   SQR((*deltaMean)[2] - true_dy));
	   	*errMed =  sqrt(SQR((*deltaMed)[0] - true_dx)  + 
			   		   SQR((*deltaMed)[2] - true_dy));
		if (verbose_active()) 
			printf("# median error: edx=%8.2f edy=%8.2f tot=%8.2f\n",
				fabs((*deltaMed)[0]-true_dx), fabs((*deltaMed)[2]-true_dy),
				sqrt(SQR((*deltaMed)[0] - true_dx) + 
					 SQR((*deltaMed)[2] - true_dy))); 
		if (verbose_active()) 
	   		printf("# mean   error: edx=%8.2f edy=%8.2f tot=%8.2f\n\n",
			   	fabs((*deltaMean)[0]-true_dx),fabs((*deltaMean)[2]-true_dy),
				sqrt(SQR((*deltaMean[0]) - true_dx) + 
					 SQR((*deltaMean)[2] - true_dy)));
	}
	free(slist1);
	free(slist2);
	return err;
}

/* select simple xform */
int	setup_simple_xform(xform_t *xform, simple_xform_t **sform,
						double theta)
{
	xform->p_size=sizeof(simple_xform_t);
	xform->pb=NULL;
	xform->pb=malloc(xform->p_size*sizeof(char));
	*sform = (simple_xform_t*)xform->pb;
	(*sform)->rot = theta;
	(*sform)->dx= -1;
	(*sform)->dy= -2;
	return 0;
}

/*--------------------------------------------------------------------------*/
