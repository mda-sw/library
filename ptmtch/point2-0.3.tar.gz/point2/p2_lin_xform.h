/*---------------------------------------------------------------------------
									E.S.O.
 ----------------------------------------------------------------------------
 * File name 	:	xform.h
 * Author		:	T. Rogon / N. Devillard 
 * Date			:	08.08.99
 * Language		:	ANSI C
 * Purpose		:	simple transformations (translation & rotoation)
 *					between 2 points sets
 *
 * The algorithm makes the following assumptions on the two point sets:
 *
 * - the 2 sets are equivalent up to a linear transformation, i.e. a
 *   translation, a rotation.
 *
 * Do not hesitate to contact the authoris in case of problems:
 * Thomas Rogon <trogon@eso.org>
 * Nicolas Devillard <nDevil@eso.org>
 *
 *-------------------------------------------------------------------------*/


#include "matchpnt.h"
#include "Murtagh.h"

/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
typedef struct  _SIMPLE_XFORM_ {
	double 	dx;					/* translation x */
	double 	dy;					/* translation y */
	double	rot; 				/* in degrees */
} simple_xform_t;


/* Function which applies a user specified geometrical transformation
   (deformation) of a point list. The transformed list may have a
   different number of points out_np (usually smaller or equal) */
typedef int(*xform_fkptr_t)(matched_point_t *input_list, int inp_np,
							char *pb,
							matched_point_t *transformed_list, int *out_np) ;
typedef struct  _XFORM_ {
	size_t			p_size;		/* size of parameter block for xform_fkptr */
	xform_fkptr_t 	xform_fkptr;/* user supplied x-form */
	char			*pb;		/* parameter block of size p_size */
} xform_t;

/* Function which estimates the geometrical transformation
   (deformation) of one point list into another. 
   	To be supplied by the user.
 	res_func is the found transformation function	*/
typedef int(*xformeval_fkptr_t)(matched_point_t *list1, int np1,
								matched_point_t *list2, int np2,
								int n_matches, xform_t *xform,
								char printfl) ;

/*---------------------------------------------------------------------------
 *						function ANSI C prototypes	
 *-------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------
 * Function	:	get_median_offsets()
 * In 		:	two point lists, number of points in both lists
 * Out 		:	a pointer to a zone containing 4 doubles
 * Job		:	compute a median offset in (dx,dy) and the average
 * 				square error associated to this offset.
 * Notice	:
 *--------------------------------------------------------------------------*/
double	*get_median_offsets(matched_point_t*,matched_point_t*,int) ;

/*----------------------------------------------------------------------------
 * Function	:	get_mean_offsets()
 * In 		:	two point lists, number of points in both lists
 * Out 		:	a pointer to a zone containing 4 doubles
 * Job		:	compute a mean offset in (dx,dy) and the average
 * 				square error associated to this offset.
 * Notice	:
 *--------------------------------------------------------------------------*/
double	*get_mean_offsets(matched_point_t*,matched_point_t*,int) ;

/*----------------------------------------------------------------------------
 * Function	:	rotate()
 * In 		:	a point lists, number of points in list,
 *				rotation angle in degrees
 * Out 		:	0 if OK, -1 if not
 * Job		:	rotate point list around origin (0,0)
 * Notice	:
 *--------------------------------------------------------------------------*/
int rotate(double angle, matched_point_t *inlist, int np);

int test_chi(matched_point_t *rlist1, matched_point_t *rlist2, 
		simple_xform_t *xform, int n_matches);
int Find_xform(const matched_point_t *list1, int np1, 
			   const matched_point_t *list2, int np2,
			   int   n_matches, xform_t *xform,
			   xformeval_fkptr_t xformeval_fkptr,
			   char printfl,
			   double **deltaMean,double **deltaMed,
			   double *errMed, double *errMean);

int Find_simple_xform(matched_point_t *slist1, int np1, 
			   matched_point_t *slist2, int np2,
			   int n_matches, xform_t *xform,
			   char printout);


int	setup_simple_xform(xform_t *xform, simple_xform_t **sform,
						double theta);
