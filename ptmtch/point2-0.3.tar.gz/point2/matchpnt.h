/*---------------------------------------------------------------------------
									E.S.O.
 ----------------------------------------------------------------------------
   File name 	:	matchpnt.h
   Author 		:	Thomas Rogon
   Created on	:	08/08/99
   Language		:	ANSI C
  					Standalone module - integratable into
					the ECLIPSE library
   Description	:	This module contains all handling of the
   					matched_point_t structure.
 *--------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------
   								Includes
 ---------------------------------------------------------------------------*/
#ifndef _MATCHED_POINT__H_
#define _MATCHED_POINT__H_

/* for size_t */
#include <stdio.h>

#ifndef _ECLIPSE_TYPES_H_
#include "p2_emockup.h"
#endif

/*---------------------------------------------------------------------------
 *								Defines	
 *-------------------------------------------------------------------------*/
#define K_FOUNDLAB (0)
#define K_KNOWNLAB (1)


#define K_PRINT_LAB (1)

/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
/* Two labels are used:
	fl (found label): the label assigned by the matching algorithm 
						(0 if no match)
	kl (known label): the label given beforehand (for test purposes)
						(0 if unknown)
	The labels permit arbitrary permutations of the lists without loss of
	correspondance information.
*/
typedef struct _MATCHED_POINT_ {
	dpoint	c;
	int    fl; 	/* computed label,  		0 if void */
	int    kl; 	/* a priori known label,    0 if void */
} matched_point_t ;

/*---------------------------------------------------------------------------
   							Function prototypes
 ---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------
 * Function	:	matched_point_2_dpoint()
 * In 		:	matched_point_t list, number of points
 * Out 		:	dpoint list labels 
 * Job		:	
 * Notice	:
 *--------------------------------------------------------------------------*/
dpoint *matched_point_2_dpoint(matched_point_t *list, int np);

/*---------------------------------------------------------------------------
 * Function	:	dpoint_2_matched_point()
 * In 		:	dpoint list, number of points
 * Out 		:	matched point list, labels zeroed
 * Job		:	
 * Notice	:
 *--------------------------------------------------------------------------*/
matched_point_t *dpoint_2_matched_point(dpoint *list, int np);


/*---------------------------------------------------------------------------
 * Function	:	read_matched_point()
 * In 		:	Input file name, number of columnsi:
 				2= X,Y 
				3= X,Y,KNOWN_LABEL) 
 * Out 		:	matched point list
 * Job		:	
 * Notice	:	lines beginning with a hatch # are ignored
 *--------------------------------------------------------------------------*/
matched_point_t* read_matched_point(char * filename, int * np,int cols) ;


/*---------------------------------------------------------------------------
 * Function	:	Test_false_match()
 * In 		:	A matched point from one list,
 				the second list and iis size
 * Out 		:	TRUE if the point has been falsely matched
 * Job		:	The found labels are checked for correspondance
 				with the known lables
 * Notice	:	unlabeled points are ignored
 *--------------------------------------------------------------------------*/
int Test_false_match(const matched_point_t p1, 
					   const matched_point_t* list2, int np2);

/*---------------------------------------------------------------------------
 * Function	:	dump_points()
 * In 		:	output file name, matched point list nb if points
 * Out 		:	0 if OK -1 if not	
 * Job		:	dumps the matched points in a text format readable by 
 *				read_matched_point
 * Notice	:
 *--------------------------------------------------------------------------*/
int dump_points(char *fn,int np, matched_point_t *list);

/*---------------------------------------------------------------------------
 * Function	:	print_matches()
 * In 		:	two matched point lists, their sizes,
 *				a sorting flag (1=sort printout by found label)
 *				a printing flag:
 *					K_PRINT_LAB : print labels too
 * Out 		:	0 if OK -1 if not
 * Job		:	prints out a table of 2 matched lists
 * Notice	:
 *--------------------------------------------------------------------------*/
int print_matches(matched_point_t *orglist1, int np1, 
				  matched_point_t *orglist2, int np2,
				  int sortflag, int printflags);

/*---------------------------------------------------------------------------
 * Function	:	count_matches()
 * In 		:	two macthed point lists, their sizes
 				a sorting flag (1=sort lists destructively by found
				label)
 * Out 		:	match sount; -1 if not OK
 * Job		:	non null found labels are counted
 * Notice	:
 *--------------------------------------------------------------------------*/
int count_matches(matched_point_t* const list1, int np1,
				  matched_point_t* const list2, int np2, int sort);
/* get index of point with known label*/
int gkl(int lab, const matched_point_t *list, size_t lsiz);

/* get index of point with found label*/
int gfl(int lab, const matched_point_t *list, size_t lsiz);

/* For sorting by label (for qsort)*/
int fl_sort(const matched_point_t *p1, const matched_point_t *p2);

/*---------------------------------------------------------------------------
 * Function	:	attach_labels_2_matched_point()
 * In 		:	matched_point_t listis number of points,
 *				correspondance lut, which labels are affected
 *				K_FOUNDLAB	-> fl
 *				K_KNOWNLAB	-> kl
 * Out 		:	0 if OK, -1 if not
 * Job		:	
 * Notice	:
 *--------------------------------------------------------------------------*/
int attach_labels_2_matched_point(
		matched_point_t *list1, int np1, 
		matched_point_t *list2, int np2,
		int *lut, int whichlab);

#endif
