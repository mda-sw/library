/*---------------------------------------------------------------------------
									E.S.O.
 ----------------------------------------------------------------------------
   File name 	:	sample.c
   Author 		:	Thomas Rogon
   Created on	:	08.08.99
   Language		:	ANSI C
   					Standalone module / 
  					Integratable into ECLIPSE library
   Description	:
 *--------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
   								Includes
 ---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* Functionalities included from other sources */
#include "matchpnt.h" 
#include "p2_lin_xform.h"
#include "Murtagh.h"
#include "p2_sample.h"
/* eclipse look-alikes for easy integration at a later stage */
#ifndef _ECLIPSE_TYPES_H_
#include "p2_emockup.h"
#endif
/*---------------------------------------------------------------------------
 *								#defines
 *-------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------
 *						function ANSI C prototypes	
 *-------------------------------------------------------------------------*/

typedef int(*qsort_fkptr_t)(const void*, const void*) ;

static int dump_results(char output_difference,  
		matched_point_t *rlist1, int np1, 
		matched_point_t *rlist2, int np2,
		int n_matches, matched_point_t *list2,
		simple_xform_t *sform, int *fm,int known_labels);

static int dump_results(char output_fl,  
		matched_point_t *rlist1, int np1, 
		matched_point_t *rlist2, int np2,
		int n_matches, matched_point_t *list2,
		simple_xform_t *sform,int *fm,int known_labels)
{	
	int		det_ok,false_det=0 ;
	int		i, j, nmax,err=0 ;
	double	res_real=-1,res_ideal=-1;

	nmax=max(np1,np2);
	if (known_labels){
		if (output_fl & (1<<OUTPUT_PAIRS))
	   		printf(
"#   x1       y1   kl  fl       x2      y2   kl fl    det    real     ideal   %d found pairs\n", n_matches) ;
	   	for (i=0 ; i<nmax ; i++) {
	   		j=0;
/* false match */
	   		if ((i<np1) && 
				(Test_false_match(rlist1[i],rlist2,np2))){
	 			det_ok =0;
	 			false_det++;
	   		} else /* correct detection */
	       		det_ok =1; 
			if (sform)
	   			res_real = sqrt(SQR(rlist1[i].c.x-sform->dx-rlist2[i].c.x)+
	                      	SQR(rlist1[i].c.y-sform->dy-rlist2[i].c.y));
   	   		j = gkl(rlist1[i].kl,list2,np2);
	   		if (j!=-1){
	   			if (sform)
	 				res_ideal = sqrt(SQR(rlist1[i].c.x-sform->dx-list2[j].c.x)+
		           		       		 SQR(rlist1[i].c.y-sform->dy-list2[j].c.y));
				if (output_fl & (1<<OUTPUT_PAIRS))
   	   	       		printf(
"%8.2f %8.2f %2d %2d   %8.2f %8.2f %2d %2d    %2d  %8.2f  %8.2f(%4d)\n", 
					rlist1[i].c.x, rlist1[i].c.y, rlist1[i].kl, rlist1[i].fl,
					rlist2[i].c.x, rlist2[i].c.y, rlist2[i].kl, rlist2[i].fl,
					det_ok, res_real, res_ideal,list2[j].kl) ;
	      	} else
				if (output_fl & (1<<OUTPUT_PAIRS))
  	      	    	printf(
"%8.2f %8.2f %2d %2d   %8.2f %8.2f %2d %2d    %2d  %8.2f     -    ( - )\n", 
					rlist1[i].c.x, rlist1[i].c.y, rlist1[i].kl, rlist1[i].fl,
					rlist2[i].c.x, rlist2[i].c.y, rlist2[i].kl, rlist2[i].fl,
					det_ok, res_real ) ;
		}
	   	if ( known_labels ) 
	    	printf("# total matches=%d: true=%d false=%d unmatched=%d\n",
					n_matches,n_matches-false_det,false_det,nmax-n_matches);
	}
	else{
		if (output_fl & (1<<OUTPUT_PAIRS)){
			err=print_matches(rlist1, np1, rlist2, np2,0, 0);
	    	printf("# %d matches found\n", n_matches) ;
		}
	}
	*fm=false_det;
	return err;
}


/*---------------------------------------------------------------------------
 * Function	:	sample()
 * In 		:	2 point lists to match with respective point numbers
 *				a rejection threshold
 * Out 		:	0 if OK -1 if not
 *				median and mean errors on linear transformations
 *				nb of false matches (if input point lists include 
 *				valid known labels
 *				search angles (min,max,precision)
 *				a flag signalling if known labels are present (==1)
 * Job		:	performs Murtagh point pattern matching,
 *				(optionally) applies a transformation,
 *				performs a rematch assuming the transformation
 * Notice	:	only linear transformation currently implemented
 *--------------------------------------------------------------------------*/
int sample(char output_flag, 
	matched_point_t *list1, int  np1,
	matched_point_t *list2, int np2,
	int    valid_threshold, 
	double *errMed, double *errMean,int *fm,
	float angmin, float angmax, double angle_prec,
	int known_labels)
{
	int		n_matches;		/* number of found matches	*/	
	double	*deltaMean=NULL,*deltaMed=NULL;	/* estimated offset		*/
	match_t	*match_tab=NULL ;	/* matching table		*/
	int		nmax ;
	xform_t	xform;
	simple_xform_t *sform=NULL;
	int		rematches=0,loop=0,lastrem=-1;
	matched_point_t *rlist1,*rlist2,*orglist1,*orglist2;
	int		err=0,n_bins;
	double  theta;
	dpoint *dlist1=NULL,*dlist2=NULL;
	correspond_lut *lut_src_2_dest;
	matched_point_t *tlist2=NULL,*trlist2=NULL;
	int	transform=LINEAR_XFORM;

	*errMed=0;
	*errMean=0;
	*fm=0;
	nmax=max(np1,np2);	/* allocate nmax since nmatches may be the
						   largest of np1,np2 */
	rlist1=calloc(nmax,sizeof(matched_point_t));
	rlist2=calloc(nmax,sizeof(matched_point_t));
	orglist1=malloc(np1*sizeof(matched_point_t));
	orglist2=malloc(np2*sizeof(matched_point_t));
	memcpy(orglist1,list1,np1*sizeof(matched_point_t));
	memcpy(orglist2,list2,np2*sizeof(matched_point_t));

	if (known_labels){
/* use matched_point_t mechanisms directly */
		if (angle_prec < MAX_ANGLE_PRECISION){
			printf("murtagh: invalid angle precision=%f (must be >%f)\n",
				angle_prec,MAX_ANGLE_PRECISION);
			free(rlist1);
			free(rlist2);
			free(orglist1);
			free(orglist2);
			return -1;
		}
		if (angmax<angmin){
			printf("murtagh: angle_min (%f) muste be < angle_max (%f)\n",
					angmin, angmax);
			return -1;
		}
		angmax +=angle_prec;
		n_bins = abs(angmax - angmin) /angle_prec;
		n_matches = murtagh_label( list1, np1, list2, np2,
			valid_threshold, (double)angmin, (double)angmax, 
			n_bins, &match_tab, &theta);
	}
	else {
/* convert matched_point_t to dpoint */
		dlist1 = matched_point_2_dpoint(list1, np1);
		dlist2 = matched_point_2_dpoint(list2, np2);
		n_matches = murtagh( dlist1, np1, dlist2, np2,
			valid_threshold, angmin, angmax, angle_prec, 
			&lut_src_2_dest, &theta);
		err=attach_labels_2_matched_point(	
				list1, np1, list2, np2, lut_src_2_dest,K_FOUNDLAB );
		free(lut_src_2_dest);
		free(dlist1);
		free(dlist2);
	}
	memcpy(rlist1,list1,np1*sizeof(matched_point_t));
	memcpy(rlist2,list2,np2*sizeof(matched_point_t));
	if (n_matches<0) {
		e_error("Exiting sample()!\n");
		free(rlist1);
		free(rlist2);
		free(orglist1);
		free(orglist2);
		if (known_labels)
			free(match_tab) ;
		return -1;
	}
/* Find/select apply transform */
	if (output_flag & (1<<OUTPUT_OFFSETS)){
		tlist2 = calloc(np2,sizeof(matched_point_t));
		trlist2 = calloc(np2,sizeof(matched_point_t));
		switch(transform){
		case LINEAR_XFORM:
			setup_simple_xform(&xform,&sform,theta); 
			err=Find_xform(list1,  np1, list2, np2,
			    n_matches, &xform, Find_simple_xform,
				(output_flag & (1<<OUTPUT_OFFSETS)),
				&deltaMean, &deltaMed, errMed,errMean) ;
			if (output_flag & (1<<REMATCH))
				(xform.xform_fkptr)(list2,np2,xform.pb,tlist2,&np2);
			break;
		case POLY2D_XFORM:
			e_error("POLY2D_XFORM (%d) not yet implemented\n",POLY2D_XFORM);
			break;
		}
		if (output_flag & (1<<REMATCH)){
	   		rematches = rematch_lists_rmsdist( list1, np1, list2, np2,
	   			rlist1,nmax,rlist2,nmax,
			     tlist2, (int)sqrt(deltaMed[1]+deltaMed[3])/2,
			   match_tab, valid_threshold,&n_matches);
		   if (verbose_active()) 
		      printf("# %d rematched point pairs, threshold=%f\n",rematches,
				  sqrt(deltaMed[1]+deltaMed[3])/2);
		}
		else{ /* copy to "output" lists */
		   memcpy(rlist1,list1,np1*sizeof(matched_point_t));
		   memcpy(rlist2,list2,np2*sizeof(matched_point_t));
		}	
		if (output_flag & (1<<REMOVE_REDUNDANTS)) {
		   do{
				(xform.xform_fkptr)(rlist2,n_matches,xform.pb,trlist2,
										&n_matches);
		      	rematches=remove_list_redundancies(rlist1,np1,rlist2,n_matches,
				   list1, np1, list2, np2, trlist2,tlist2,match_tab, 
				   valid_threshold, (int)sqrt(deltaMed[1]+deltaMed[3])/2);
		      	if (verbose_active()) 
   		       		printf("# %d rematched redundant point pairs (loop%d)\n", 
						rematches,loop) ;
		      	if (lastrem == rematches)
		        	break;
		      	else
		        	lastrem = rematches;
		  	}while ((loop++<5) && rematches);   
		}
	}
    n_matches=count_matches(rlist1, np1, rlist2, np2, 0 );
	if (!err )
		err = dump_results(output_flag,
				rlist1,np1,rlist2,np2,n_matches,list2,sform,fm,
				known_labels );

	if (deltaMed)
		free(deltaMed) ;
	if (deltaMean)
		free(deltaMean) ;
	if (match_tab)
		free(match_tab) ;
	free(orglist1);
	free(orglist2);
	free(rlist1);
	free(rlist2);
	if (sform)
		free(sform);
	if (tlist2)
		free(tlist2);
	if (trlist2)
		free(trlist2);
	return err ;
}

/*--------------------------------------------------------------------------*/
