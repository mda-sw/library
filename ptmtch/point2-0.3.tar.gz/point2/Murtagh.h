#ifndef _MURTAGH_H_
#define _MURTAGH_H_

#include "matchpnt.h"

/*---------------------------------------------------------------------------
 *								Defines	
 *-------------------------------------------------------------------------*/
#define MAX_ANGLE_PRECISION (.00001)


/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
typedef float match_t;
#define WORST_MARK (0.0)
#define BEST_MARK  (1.0)

/* lookup table of point correspondances; -1 means no match */
typedef int correspond_lut;




/*---------------------------------------------------------------------------*/
/* 							Public function prototypes 						 */
/*---------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------
 * Function	:	murtagh_label()
 * In 		:	two point lists & related number of points, 
 *				a rejection threshold
 *				a minimal, maximal angle & # of angle_bins for rotation
 * Out 		:	number of matches if OK, -1 if not
 *				a match table
 *				a rotation angle estimate.
 * Job		:	matches 2 point lists.
 * Notice	:	The algorithm makes the following assumptions on the 
 *				two point sets:
 * 					- the 2 sets are equivalent up to a linear 
 *						transformation, i.e. a translation, a rotation, 
 *						and a scale factor (zoom).
 * 					- corresponding point positions can be noisy, a 
 *						displacement of up to  a few pixels is tolerated.
 * 					- some points in a point set may have no equivalent 
 *						in the other set.
 * 				This implementation uses most choices taken by Murtagh in 
 * 				his paper, including rotations.
 *--------------------------------------------------------------------------*/
int murtagh_label( matched_point_t *list1, int  np1, 
				   matched_point_t *list2, int np2, int valid_threshold, 
				   double angle_min, double angle_max, int angle_bins,
				   match_t **match_tab, double *Theta);

/*----------------------------------------------------------------------------
 * Function	:	murtagh()
 * In 		:	two point lists & related number of points, 
 *				a rejection threshold
 *				a minimal, maximal angle for rotation
 *				an angle precision (e.g 1.0 degs, 0.1 degs) for rotation
 * Out 		:	number of matches if OK, -1 if not
 *				a correspondance lut
 *				a rotation angle estimate.
 * Job		:	matches 2 point lists.
 * Notice	:	This is a wrapper function to murtagh_label 
 *				using eclipse data structures - see murtagh_label()
 *				for details
 *--------------------------------------------------------------------------*/
int murtagh( dpoint *list1, int np1, 
			 dpoint *list2, int np2,
	int valid_threshold, double angle_min, double angle_max,
	double angle_prec, correspond_lut **lut_src_2_dest, double *Theta);


/*----------------------------------------------------------------------------
* Function     :       rematch_lists_rmsdist()
* In           :       two lists of points:
*						  	2 input lists
*                      		the second list with applied transormation , 
*		       				a threshold for residual rematch
* Out          :       The  matched point list is modified. 
*			  				2 output lists
*                      The number of rematches is returned.
* Job          :       Rematches 2 point lists by assuming a  given 
*					   transformation  and 
*                      selecting the least squares error solution.
*--------------------------------------------------------------------------*/
int rematch_lists_rmsdist( 
	matched_point_t *ilist1, int inp1, matched_point_t *ilist2, int inp2,
	matched_point_t *olist1, int onp1, matched_point_t *olist2, int onp2,
	matched_point_t *tlist2,   match_t residual_threshold,
	match_t *matchres, int valid_threshold, int *n_matches);


/*----------------------------------------------------------------------------
* Function     :    remove_list_redundancies()
* In           :    2 matched lists, 
*                   2 transformed lists tlist2,otlist2 
* Out          :    The 2nd matched point list is modified. 
*                   The number of rematches is returned.
* Job          :    Rematches 2 point lists by removing redundancies i.e.
*		       		multiple points in list1 matched to single point in list2
*                   The match is performed under the constraint of least sum 
*		       		of square error.
* Notice	:      	The rematch may create new redundancies; Repeated calls
*	               	of this procedure should reduce the redundancies, but 
*		       		there is no guarantee of convergence (!)
*--------------------------------------------------------------------------*/
int remove_list_redundancies( 
	matched_point_t *rlist1, int rnp1, matched_point_t *rlist2, int rnp2,
    matched_point_t *olist1, int onp1, matched_point_t *olist2, int onp2,
    matched_point_t *tlist2, matched_point_t *otlist2, 
	match_t *matchres, int valid_threshold,
    int resmax);


#endif
