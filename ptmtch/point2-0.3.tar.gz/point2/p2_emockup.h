#ifndef _E_MOCKUP_H_
#define _E_MOCKUP_H_

/*---------------------------------------------------------------------------
   								New types
 ---------------------------------------------------------------------------*/
typedef struct _DPOINT_ {
	double x ;
	double y ;
} dpoint ;

/* The following structure is useful to store a unit of point "world
 * view", i.e. a distance and an angle from a point to another point.
 * The distance is normalized to [0..1], 0 being the farthest distance,
 * 1 being the distance from the point to itself.
 * The angle is converted to degrees, in the interval [0..360] */
typedef struct _DMEAS_ 
{
	double	dis ;		/* normalized distance to the point */
	double	ang ;		/* angle in [0..360] degrees		*/
} dmeas ;

extern int g_verbose_active ;
#define verbose_active()	(g_verbose_active) 
extern int g_debug_active ;
#define debug_active()		(g_debug_active)

/* x^2 macro */
#define SQR(x) ((x)*(x))

#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef SIZE
#define SIZE 1024
#endif

#define e_warning printf
#define e_error printf

/*---------------------------------------------------------------------------
   							Function prototypes
 ---------------------------------------------------------------------------*/
/* these functions are simplified cut'npasted from the eclipse 
   library see messages.h 
void e_error(char *fmt, ...);
void e_warning(char *fmt, ...);
*/
#endif
