#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include "p2_emockup.h"


/* these functions are simplified cut'npasted from the eclipse 
   library see messages.c 

void e_warning(char *fmt, ...)
{
	char   *msg ;
	va_list	ap ;
	char    logmsg[1024] ;

	fprintf(stderr, "\nWarning: ") ;
	msg = strdup(fmt) ;

	va_start(ap, fmt) ;
	vfprintf(stderr, msg, ap) ;
	vsprintf(logmsg, msg, ap) ;
	va_end(ap) ;
	
	fprintf(stderr, "\n") ;
	fflush(stderr) ;
	free(msg) ;
	return ;

}

void e_error(char *fmt, ...)
{
	char  * msg ;
	va_list	ap ;
	char	logmsg[1024] ;

	fprintf(stderr, "\nError: ") ;
	msg = strdup(fmt) ;

	va_start(ap, fmt) ;
	vfprintf(stderr, msg, ap) ;
	vsprintf(logmsg, msg, ap) ;
	va_end(ap) ;

	free(msg) ;
	fprintf(stderr, "\n") ;
	fflush(stderr) ;
}
*/
