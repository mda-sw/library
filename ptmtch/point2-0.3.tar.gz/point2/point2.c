#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* Functionalities included from other sources */
#include "matchpnt.h" 

#include "p2_lin_xform.h"

#include "Murtagh.h"
#include "p2_sample.h"
/*---------------------------------------------------------------------------
 *								#defines
 *-------------------------------------------------------------------------*/


/* eclipse look-alikes for easy integration at a later stage */
#ifndef _ECLIPSE_TYPES_H_
int g_verbose_active = 0;
#define verbose_active()	(g_verbose_active) 
int g_debug_active = 0;
#define debug_active()		(g_debug_active)
#define SIZE 				1024
#endif


/*---------------------------------------------------------------------------
 *						function ANSI C prototypes	
 *-------------------------------------------------------------------------*/

/* Public functions */
static void usage(char *) ;

/* global variables used only by getopt() */
extern char *optarg ;
extern int   optind ;


/*---------------------------------------------------------------------------
 *									main()	
 *-------------------------------------------------------------------------*/
int main(int argc, char *argv[]) 
{
	matched_point_t	*inlist1,*inlist2;		/* input point lists		*/
	int			c,np1, np2;
	int			valid_threshold=30 ;
	char		name1[80],name2[80] ;
	int			fm;
	char		outflag=NO_OUTPUT;
	int			err=0;
	float		angmin=ANGMIN_DEF,angmax=ANGMAX_DEF,angle_prec=ANGPREC_DEF;
	int			parms2read=2;
	double		errMed,errMean;

	if (argc<2) 
	   usage(argv[0]) ;

	valid_threshold = BEST_MATCHES ;

/* get options from command line */
	while ((c=getopt(argc, argv, "opa:t:vdkr")) != EOF)
		switch(c){
/* t changes the threshold from 30 to something else */
		case 't':
			valid_threshold = atoi(optarg) ;
			if ((valid_threshold<1) || (valid_threshold>100)) {
				fprintf(stderr,
					"invalid threshold: %d -- must be in [1..100]\n",
					valid_threshold) ;
				return -1 ;
			}
			break ;

		case 'a':
			sscanf(optarg, "%f %f %f", &angmin, &angmax, &angle_prec) ;
			break ;

		case 'r':
			outflag |= (1<<REMATCH)|(1<<REMOVE_REDUNDANTS);
			break;

		case 'p':
			outflag |= (1<<OUTPUT_PAIRS) ;
			break ;

		case 'o':
			outflag |= (1<<OUTPUT_OFFSETS) ;
			break ;

		case 'k':
			parms2read=3;
			break;

#ifndef _ECLIPSE_TYPES_H_
		case 'v':
			g_verbose_active=1;
			break;

		case 'd':
			g_debug_active=1;
			break;
#endif				
		default:
		   usage(argv[0]) ;
		   break ;
		}

#ifdef _ECLIPSE_TYPES_H_
	eclipse_init() ; 
#endif
	if ((argc-optind<2)) {
		fprintf(stderr, "missing arguments: list file names\n") ;
		return -1 ;
	}
	strcpy(name1, argv[optind++]) ;
	strcpy(name2, argv[optind++]) ;
	if (verbose_active())
		printf("# %s: reading ",name1);
	inlist1 = read_matched_point(name1, &np1,parms2read) ;
	if (inlist1){
		if (verbose_active()){
			printf("%d points\n",np1);
			printf("# %s: reading ",name2);
		}
	}
	else
		return -1;		
   	inlist2 = read_matched_point(name2, &np2,parms2read) ;
	if (inlist2){
		if (verbose_active()){
			printf("%d points\n",np2);
			printf(
		"# Using angmin=%6.2f angmax=%6.2f precision=%4f, parmsread=%d\n"
				,angmin,angmax,angle_prec,parms2read);
		}
	}
	else
		return -1;		
	err=sample( outflag, inlist1,np1,inlist2,np2, valid_threshold,
			&errMed,&errMean,&fm, angmin,angmax,(double)angle_prec,(parms2read==3)) ;
	free(inlist1) ;
	free(inlist2) ;
#ifdef _MEMORY_H_
	memory_status() ;
#endif	
	return err ;
}


/*  This outputs a short help text to use the program and exits */
static void usage(char *pname)
{
	fprintf(stderr,"use: %s [options] <list1> <list2>\n",
		pname) ;
	fprintf(stderr,"arguments are:\n");
	fprintf(stderr,"   -a '<angmin> <angmax> <angprec>'\n");
	fprintf(stderr,"\tangmin is the minimal angle (default=%f)\n",ANGMIN_DEF);
	fprintf(stderr,"\tangmax is the maximal angle (default=%f)\n",ANGMAX_DEF);
	fprintf(stderr,
			"\tangprec is the angle precision (default=%f)\n",ANGPREC_DEF);
	fprintf(stderr,"   -t <threshold>\n");
	fprintf(stderr,"\tthreshold is the rejection threshold (default=30)\n");
	fprintf(stderr,"   -r : rematch using found transformation\n");
	fprintf(stderr,
		"   -k : use supplied a priori labels to evaluate success rates\n");
	fprintf(stderr,"   -p : output pairs of matched points\n") ;
	fprintf(stderr,"   -o : output a median offset\n") ;
	fprintf(stderr,"   <list1> : a text file containing x and y coordinates and optionally a label number (see -k)\n") ;
	fprintf(stderr,"   <list2> : same as list1\n") ;
	exit(0) ;
}

/*--------------------------------------------------------------------------*/
